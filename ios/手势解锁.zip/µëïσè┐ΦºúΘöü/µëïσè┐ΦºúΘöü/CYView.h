//
//  CYView.h
//  手势解锁
//
//  Created by hezi on 2021/11/12.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CYView : UIView

@property (nonatomic, copy) BOOL(^passwordBlock)(NSString *);

@end

NS_ASSUME_NONNULL_END
