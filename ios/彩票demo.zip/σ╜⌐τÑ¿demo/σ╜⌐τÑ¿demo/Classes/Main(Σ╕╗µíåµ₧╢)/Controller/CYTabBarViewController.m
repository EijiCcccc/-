//
//  CYTabBarViewController.m
//  彩票demo
//
//  Created by 小纯子 on 2021/11/16.
//

#import "CYTabBarViewController.h"
#define kTabBarHeight 84

@interface CYTabBarButton : UIButton

@end

@implementation CYTabBarButton

- (void)setHighlighted:(BOOL)highlighted {
//    [super setHighlighted: highlighted];
}
    
@end

@interface CYTabBarViewController ()

@property (nonatomic, weak) UIButton *currentBtn;

@end

@implementation CYTabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIViewController *v1 = [self loadSubViewControllerWithSBName: @"Hall"];
    UIViewController *v2 = [self loadSubViewControllerWithSBName: @"Arena"];
    UIViewController *v3 = [self loadSubViewControllerWithSBName: @"Discovery"];
    UIViewController *v4 = [self loadSubViewControllerWithSBName: @"History"];
    UIViewController *v5 = [self loadSubViewControllerWithSBName: @"MyLottery"];
    
    self.viewControllers = @[v1, v2, v3, v4, v5];
    
    UIView *tabbar = [[UIView alloc] init];
    CGRect frame = self.tabBar.frame;
    frame.origin.y = kScreenHeight - kTabBarHeight;
    frame.size.height = kTabBarHeight;
    tabbar.frame = frame;
//    tabbar.backgroundColor = [UIColor redColor];
    
    NSArray *array = @[@"bifen_select_Image", @"faxian_select_Image", @"gendan_select_Image", @"goucai_select_Image", @"wo_select_Image"];
    
    NSArray *array1 = @[@"bifen_Image", @"faxian_Image", @"gendan_Image", @"goucai_Image", @"wo_Image"];
    
    for (int i = 0; i < self.viewControllers.count; i ++) {
        CYTabBarButton *tabbarButton = [[CYTabBarButton alloc] init];
        tabbarButton.tag = i;
        CGFloat w = kScreenWidth / 5;
        CGFloat h = 49;
        CGFloat x = i * w   ;
        CGFloat y = 0;
        tabbarButton.frame = CGRectMake(x, y, w, h);
        [tabbarButton setImage: [UIImage imageNamed: array[i]] forState: UIControlStateNormal];
        [tabbarButton setImage: [UIImage imageNamed: array1[i]] forState: UIControlStateSelected];
        
        [tabbarButton addTarget: self action: @selector(tabBarButtonClick:) forControlEvents: UIControlEventTouchDown];
        
        [tabbar addSubview: tabbarButton];
    }
    
    [self.view addSubview: tabbar];
    // Do any additional setup after loading the view.
}


//- (void)viewDidLayoutSubviews {
//    [super viewDidLayoutSubviews];
//
//    CGRect frame = self.tabBar.frame;
//
//    frame.size.height = kTabBarHeight;
//
//    frame.origin.y = self.view.bounds.size.height - kTabBarHeight;
//
//    self.tabBar.frame = frame;
//
//}

-(void)tabBarButtonClick: (UIButton *)sender {
    self.currentBtn.selected = NO;
    sender.selected = YES;
    self.currentBtn = sender;
    self.selectedIndex = sender.tag;
}

-(UIViewController *)loadSubViewControllerWithSBName: (NSString *)name {
    UIStoryboard *sb = [UIStoryboard storyboardWithName: name bundle: nil];
    return [sb instantiateInitialViewController];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
