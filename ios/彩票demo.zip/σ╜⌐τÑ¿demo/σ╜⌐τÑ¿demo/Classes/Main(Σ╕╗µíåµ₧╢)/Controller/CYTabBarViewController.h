//
//  CYTabBarViewController.h
//  彩票demo
//
//  Created by 小纯子 on 2021/11/16.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CYTabBarViewController : UITabBarController

@end

NS_ASSUME_NONNULL_END
