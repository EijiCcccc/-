//
//  AppDelegate.h
//  彩票demo
//
//  Created by 小纯子 on 2021/11/16.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;

@end

