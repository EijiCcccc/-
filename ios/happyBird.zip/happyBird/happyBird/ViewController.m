//
//  ViewController.m
//  happyBird
//
//  Created by hezi on 2021/11/16.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <UICollisionBehaviorDelegate>

@property (nonatomic, strong) UIDynamicAnimator *animator;

@property (nonatomic, strong) UIGravityBehavior *gravity;

@property (nonatomic, strong) UIView *bird;

@end

@implementation ViewController

-(UIDynamicAnimator *)animator {
    if (!_animator) {
        _animator = [[UIDynamicAnimator alloc] initWithReferenceView: self.view];
    }
    return  _animator;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIView *bird = [[UIView alloc] initWithFrame: CGRectMake(150, 250, 30, 30)];
    bird.backgroundColor = [UIColor redColor];
    [self.view addSubview: bird];
    self.bird = bird;
    // Do any additional setup after loading the view.
    
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget: self action: @selector(pan:)];
    [bird addGestureRecognizer: pan];
    
    UIView *pig = [[UIView alloc] initWithFrame:CGRectMake(700, 300, 30, 30)];
    pig.backgroundColor = [UIColor blueColor];
    [self.view addSubview:pig];
    
    UICollisionBehavior *collision = [[UICollisionBehavior alloc] initWithItems: @[pig, bird]];
    
    collision.translatesReferenceBoundsIntoBoundary = YES;
    
    collision.collisionDelegate = self;
    [self.animator addBehavior: collision];
}

-(void)pan: (UIPanGestureRecognizer *)sender {
    //移动偏移量
    CGPoint offset = [sender translationInView: sender.view];
    //当前位置
    CGPoint currentPoint = [sender locationInView: self.view];
    
    
    CGFloat offsetX = sender.view.center.x - currentPoint.x;
    CGFloat offsetY = sender.view.center.y - currentPoint.y;
    
    
    CGFloat distance = sqrt(offsetX * offsetX + offsetY * offsetY);
    
    //绘制一个范围
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathAddArc(path, NULL, sender.view.center.x, sender.view.center.y, 100, 0, 2 * M_PI, 1);
    if (CGPathContainsPoint(path, NULL, currentPoint, NO)) {
        if (sender.state == UIGestureRecognizerStateEnded) {
            UIGravityBehavior *gravity = [[UIGravityBehavior alloc] initWithItems:@[sender.view]];
            self.gravity = gravity;
            [self.animator addBehavior: gravity];
            
            UIPushBehavior *push = [[UIPushBehavior alloc] initWithItems:@[sender.view] mode:UIPushBehaviorModeInstantaneous];
            
            push.pushDirection = CGVectorMake(offsetX, offsetY);
            
            push.magnitude = distance / 100;
            [self.animator addBehavior: push];
        }
    } else {
        return;
    }
    
    
    //改变view的transform
    sender.view.transform = CGAffineTransformTranslate(sender.view.transform, offset.x, offset.y);
    //归0
    [sender setTranslation: CGPointZero inView:sender.view];
    
    
}

-(void)collisionBehavior:(UICollisionBehavior *)behavior beganContactForItem:(id<UIDynamicItem>)item1 withItem:(id<UIDynamicItem>)item2 atPoint:(CGPoint)p {
    [self.gravity addItem: item1];
}

-(void)collisionBehavior:(UICollisionBehavior *)behavior endedContactForItem:(id<UIDynamicItem>)item withBoundaryIdentifier:(id<NSCopying>)identifier {
    
}

@end
