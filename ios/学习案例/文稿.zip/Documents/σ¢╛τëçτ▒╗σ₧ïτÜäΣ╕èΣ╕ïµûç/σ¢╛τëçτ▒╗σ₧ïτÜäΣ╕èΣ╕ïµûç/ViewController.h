//
//  ViewController.h
//  图片类型的上下文
//
//  Created by hezi on 2021/11/11.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

