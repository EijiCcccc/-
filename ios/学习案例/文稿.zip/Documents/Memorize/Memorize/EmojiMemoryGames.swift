//
//  EmojiMemoryGames.swift
//  Memorize
//
//  Created by hezi on 2021/10/18.
//  Copyright © 2021 hezi. All rights reserved.
//

import SwiftUI

class EmojiMemoryGames: ObservableObject {
    
    @Published private var model: MemoryGames<String> = createMemoryGame()
    
    private static func createMemoryGame() -> MemoryGames<String> {
        let emojis: Array<String> = ["👻", "😀", "💀"]
        return MemoryGames<String>(numberOfPairsOfCards: emojis.count) {
               pairIndex in emojis[pairIndex]
           }
    }
    
    //MARK: - Access to the Model
    
    var cards: Array<MemoryGames<String>.Card> {
        model.cards
    }
    
    //MARK: - Intent(s)
    
    func choose(card: MemoryGames<String>.Card) {
        model.choose(card: card)
    }
    
    func resetGame() {
        model = EmojiMemoryGames.createMemoryGame()
    }
}
