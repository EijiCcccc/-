//
//  Array+Only.swift
//  Memorize
//
//  Created by hezi on 2021/10/19.
//  Copyright © 2021 hezi. All rights reserved.
//

import Foundation

extension Array {
    var only: Element? {
        count == 1 ? first : nil
    }
}
