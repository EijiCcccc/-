//
//  CYView.m
//  自定义进度条
//
//  Created by hezi on 2021/11/11.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "CYView.h"

@interface CYView ()

@property (nonatomic, weak) IBOutlet UILabel *labe;

@end

@implementation CYView

- (void)setProgressValue:(CGFloat)progressValue {
    _progressValue = progressValue;
    [self setNeedsDisplay];
    
    //在字符串中 %% = @"%"
     self.labe.text = [NSString stringWithFormat: @"%.2f%%", self.progressValue * 100];
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter: CGPointMake(150, 150) radius: 100 startAngle: 0 - M_PI_2 endAngle: 2 * M_PI * self.progressValue - M_PI_2 clockwise: 1];
    [path addLineToPoint:CGPointMake(150, 150)];
    [[UIColor redColor] set];
    [path fill];
}

@end
