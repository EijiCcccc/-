//
//  ViewController.m
//  自定义进度条
//
//  Created by hezi on 2021/11/11.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ViewController.h"
#import "CYView.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet CYView *progressView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}
- (IBAction)valueChanged:(UISlider *)sender {
    self.progressView.progressValue = sender.value;
}


@end
