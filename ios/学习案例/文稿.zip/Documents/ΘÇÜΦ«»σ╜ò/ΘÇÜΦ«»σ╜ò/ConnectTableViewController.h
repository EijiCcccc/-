//
//  ConnectTableViewController.h
//  通讯录
//
//  Created by hezi on 2021/11/10.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ConnectTableViewController : UITableViewController

@property (nonatomic, copy) NSString *name;

@end

NS_ASSUME_NONNULL_END
