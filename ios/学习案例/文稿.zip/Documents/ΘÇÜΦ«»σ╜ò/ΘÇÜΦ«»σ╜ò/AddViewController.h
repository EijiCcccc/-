//
//  AddViewController.h
//  通讯录
//
//  Created by hezi on 2021/11/10.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Connect.h"


@class AddViewController;
@protocol AddViewControllerDelegate <NSObject>

@optional
-(void)addViewController: (AddViewController *)addViewController withConnect: (Connect *)connect;
@end


@interface AddViewController : UIViewController

@property (nonatomic, weak) id<AddViewControllerDelegate> delegate;

//@property (nonatomic, copy) void (^addResultBlock)(AddViewController *, Connect *);

@end

