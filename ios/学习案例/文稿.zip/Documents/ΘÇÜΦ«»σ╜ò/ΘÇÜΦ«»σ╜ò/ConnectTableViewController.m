//
//  ConnectTableViewController.m
//  通讯录
//
//  Created by hezi on 2021/11/10.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ConnectTableViewController.h"
#import "AddViewController.h"
#import "EditViewController.h"

//NSSearchPathForDirectoriesInDomains第三个参数：如果路径不展开， 系统会把沙盒的根目录替换成～
//wirteToFile 第二个参数 atomically:线程同步，YES会先写入一个缓存区，防止写到一半丢失数据

#define kFilePath [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0] stringByAppendingString:@"/contacts.data"]

@interface ConnectTableViewController () <AddViewControllerDelegate, EditViewControllerDelegate>

@property (nonatomic, strong) NSMutableArray *contacts;

@end

@implementation ConnectTableViewController

-(NSMutableArray *)contacts {
    if (!_contacts) {
        _contacts = [NSMutableArray array];
    }
    return _contacts;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    UIBarButtonItem *Item = [[UIBarButtonItem alloc] initWithTitle: @"注销" style: UIBarButtonItemStylePlain target: self action: @selector(logOut)];
    self.navigationItem.leftBarButtonItem = Item;
    self.navigationItem.title = [NSString stringWithFormat:@"%@的联系人", self.name];
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self.tableView setSeparatorInset: UIEdgeInsetsMake(0, 0, 0, 0)];
    
    self.contacts = [NSKeyedUnarchiver unarchiveObjectWithFile: kFilePath];
//    NSData * unData = [NSData dataWithContentsOfFile: kFilePath];
//    Connect *p1 = [NSKeyedUnarchiver unarchivedObjectOfClass: [Connect class] fromData: unData error: nil];
    
    //    UIBarButtonItem *Item1 = [[UIBarButtonItem alloc] initWithTitle: @"注销" style: UIBarButtonItemStyleDone target: self action: nil];
//    self.navigationItem.leftBarButtonItems = @[Item, Item1];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

-(void)logOut {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle: @"你确定注销吗？" message:nil preferredStyle: UIAlertControllerStyleActionSheet];
    [alert addAction: [UIAlertAction actionWithTitle: @"确定" style: UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self.navigationController popViewControllerAnimated: YES];
    }]];
    [alert addAction: [UIAlertAction actionWithTitle: @"取消" style: UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {

    }]];
    [self presentViewController:alert animated:true completion:nil];
//    [alert showInView: self.view];
}

-(void)addViewController:(AddViewController *)addViewController withConnect:(Connect *)connect {
    [self.contacts addObject: connect];
    [self.tableView reloadData];
    
    NSLog(@"%@", kFilePath);
//    [NSKeyedArchiver archivedDataWithRootObject: connect requiringSecureCoding: YES error: nil];
//    [NSKeyedArchiver archiveRootObject: self.contacts toFile:filePath];
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject: self.contacts requiringSecureCoding: YES error: nil];
    [data writeToFile: kFilePath atomically: YES];
}

-(void)editViewController:(EditViewController *)editviewController andContact:(Connect *)contact {
    [self.tableView reloadData];
    
    [NSKeyedArchiver archiveRootObject: self.contacts toFile: kFilePath];
}

//-(void)viewWillAppear:(BOOL)animated {
//    [super viewWillAppear: animated];
//    [self.tableView reloadData];
//}


- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    UIViewController *vc = segue.destinationViewController;
    if ([vc isKindOfClass: [AddViewController class]]) {
        AddViewController *add = (AddViewController *)vc;
        add.delegate = self;
    } else {
        EditViewController *edit = (EditViewController *)vc;
        
        NSIndexPath *path = [self.tableView indexPathForSelectedRow];
        Connect *connect = self.contacts[path.row];
        edit.delegate = self;
        edit.contact = connect;
    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.contacts.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId = @"contact_cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier: cellId forIndexPath:indexPath];
    cell.textLabel.text = [self.contacts[indexPath.row] name];
    cell.detailTextLabel.text = [self.contacts[indexPath.row] number];
    // Configure the cell...
    
    return cell;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    [self.contacts removeObjectAtIndex: indexPath.row];
    //delete之后会调用数据源方法 numberOfRowsInSection，先删除模型再行
    [self.tableView deleteRowsAtIndexPaths: @[indexPath] withRowAnimation: UITableViewRowAnimationLeft];
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
