//
//  AddViewController.m
//  通讯录
//
//  Created by hezi on 2021/11/10.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "AddViewController.h"

@interface AddViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UITextField *phoneTextField;
@property (weak, nonatomic) IBOutlet UIButton *addBtn;

@end

@implementation AddViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.nameTextField addTarget: self action: @selector(textChanged) forControlEvents: UIControlEventEditingChanged];
    [self.phoneTextField addTarget: self action: @selector(textChanged) forControlEvents: UIControlEventEditingChanged];
    [self.nameTextField becomeFirstResponder];
    // Do any additional setup after loading the view.
}
- (IBAction)addBtnClick:(id)sender {
//    if (self.addResultBlock) {
//        Connect *connect = [Connect new];
//        connect.name = self.nameTextField.text;
//        connect.number = self.phoneTextField.text;
//        self.addResultBlock(self, connect);
//    }
    /*
     获取doc路径
     
     NSString *str = NSHomeDirectory();
     NSString *path = [NSString stringWithFormat:@"%@/Doucments", str];
     
     
     NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory directory, NSSearchPathDomainMask domainMask, BOOL expandTilde);
     */
//    NSString *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    
    if ([self.delegate respondsToSelector:@selector(addViewController:withConnect:)]) {
        Connect *connect = [Connect new];
        connect.name = self.nameTextField.text;
        connect.number = self.phoneTextField.text;
        [self.delegate addViewController: self withConnect: connect];
    }
    
    [self.navigationController popViewControllerAnimated: YES];
}

-(void)textChanged {
    self.addBtn.enabled = self.nameTextField.text.length > 0 && self.phoneTextField.text.length > 0;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
