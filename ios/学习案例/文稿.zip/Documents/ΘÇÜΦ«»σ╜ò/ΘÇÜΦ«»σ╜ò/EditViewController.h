//
//  EditViewController.h
//  通讯录
//
//  Created by hezi on 2021/11/10.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Connect.h"

@class  EditViewController;
@protocol EditViewControllerDelegate <NSObject>

-(void)editViewController: (EditViewController *)editviewController andContact: (Connect *)contact;

@end

@interface EditViewController : UIViewController

@property (nonatomic, strong) Connect *contact;
@property (nonatomic, weak) id<EditViewControllerDelegate> delegate;

@end

