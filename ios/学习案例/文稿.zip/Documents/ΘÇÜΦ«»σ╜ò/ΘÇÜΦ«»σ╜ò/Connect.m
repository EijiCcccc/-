//
//  Connect.m
//  通讯录
//
//  Created by hezi on 2021/11/10.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "Connect.h"

@implementation Connect

//告诉需要归档那些属性
-(void)encodeWithCoder:(NSCoder *)coder {
    [coder encodeObject:_name forKey:@"name"];
    [coder encodeObject:_number forKey:@"number"];
}

+(BOOL)supportsSecureCoding {
    return YES;
}

//告诉系统解档哪些属性
- (nullable instancetype)initWithCoder:(nonnull NSCoder *)coder {
    if(self = [super init]) {
        _name = [coder decodeObjectForKey: @"name"];
        _number = [coder decodeObjectForKey: @"number"];
    }
    return self;
}

@end
