//
//  EditViewController.m
//  通讯录
//
//  Created by hezi on 2021/11/10.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "EditViewController.h"

@interface EditViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameTextFeild;
@property (weak, nonatomic) IBOutlet UITextField *phoneTextField;
@property (weak, nonatomic) IBOutlet UIButton *saveBtn;

@end

@implementation EditViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.nameTextFeild.text = self.contact.name;
    self.phoneTextField.text = self.contact.number;
    // Do any additional setup after loading the view.
}
- (IBAction)eidtBtnClick:(UIBarButtonItem *)sender {
    if (self.saveBtn.hidden) {
        sender.title = @"取消";
        self.nameTextFeild.enabled = YES;
        self.phoneTextField.enabled = YES;
        self.saveBtn.hidden = NO;
        [self.nameTextFeild becomeFirstResponder];
    } else {
        sender.title = @"编辑";
        self.nameTextFeild.enabled = NO;
        self.phoneTextField.enabled = NO;
        self.saveBtn.hidden = YES;

        self.nameTextFeild.text = self.contact.name;
        self.phoneTextField.text = self.contact.number;
    }
}

- (IBAction)saveBtnClick:(id)sender {
    self.contact.name = self.nameTextFeild.text;
    self.contact.number = self.phoneTextField.text;
    if ([self.delegate respondsToSelector:@selector(editViewController:andContact:)]) {
        [self.delegate editViewController: self andContact: self.contact];
    }
    [self.navigationController popViewControllerAnimated: YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
