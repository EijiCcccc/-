//
//  LoginViewController.m
//  通讯录
//
//  Created by hezi on 2021/11/9.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "LoginViewController.h"
#import <MBProgressHUD/MBProgressHUD.h>
#import "ConnectTableViewController.h"

#define kUserNameKey @"kUserNameKey"
#define kPasswordKey @"kPasswordKey"
#define kRemPasswordKey @"kRemPasswordKey"
#define kAutoLoginKey @"kAutoLoginKey"

@interface LoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *userNameTextField;
@property (weak, nonatomic) IBOutlet UITextField *pwdTextField;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;
@property (weak, nonatomic) IBOutlet UISwitch *remPassword;
@property (weak, nonatomic) IBOutlet UISwitch *autoLogin;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.userNameTextField addTarget: self action:@selector(textChanged) forControlEvents: UIControlEventEditingChanged];
    [self.pwdTextField addTarget: self action:@selector(textChanged) forControlEvents: UIControlEventEditingChanged];
    // Do any additional setup after loading the view.
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    self.remPassword.on = [ud boolForKey: kRemPasswordKey];
    self.autoLogin.on = [ud boolForKey: kAutoLoginKey];
    self.userNameTextField.text = [ud objectForKey: kUserNameKey];
    if (self.remPassword.isOn) {
        self.pwdTextField.text = [ud objectForKey: kPasswordKey];
    }
    if (self.autoLogin.isOn) {
        [self loginBtnClick: self.loginBtn];
    }
    [self textChanged];
}

- (IBAction)loginBtnClick:(id)sender {
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)( 0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [MBProgressHUD hideHUDForView: self.view animated: YES];
        if ([self.userNameTextField.text isEqualToString: @"1"] &&
            [self.pwdTextField.text isEqualToString:@"1"]) {
            NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
            [ud setBool: self.remPassword.isOn forKey:kRemPasswordKey];
            [ud setBool: self.autoLogin.isOn forKey:kAutoLoginKey];
            [ud setObject: self.userNameTextField.text forKey:kUserNameKey];
            [ud setObject: self.pwdTextField.text forKey:kPasswordKey];
            [ud synchronize];
            [self performSegueWithIdentifier: @"login2" sender: nil];
        }
    });
}

-(void)textChanged {
    if (self.userNameTextField.text.length > 0 && self.pwdTextField.text.length > 0) {
        self.loginBtn.enabled = YES;
    } else {
        self.loginBtn.enabled = NO;
    }
}

////文本框开始编辑
//- (void)textFieldDidBeginEditing:(UITextField *)textField {
//
//}
////是否允许结束这个文本框结束编辑
////-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
////    return  NO;
////}
//
////文本框已经结束编辑
//- (void)textFieldDidEndEditing:(UITextField *)textField {
//
//}
- (IBAction)remSwitchClick:(UISwitch *)sender {
    if (!sender.isOn) {
//        self.autoLogin.on = NO;
        [self.autoLogin setOn: NO animated: YES];
    }
}
- (IBAction)autoLoginSwitchClick:(UISwitch *)sender {
    if (sender.isOn) {
//        self.remPassword.on = YES;
        [self.remPassword setOn: YES animated: YES];
    }
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
//    segue.destinationViewController.name =
    ConnectTableViewController *vc = segue.destinationViewController;
    vc.name = self.pwdTextField.text;
}

@end
