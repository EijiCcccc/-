//
//  ContentView.swift
//  EmojiArt
//
//  Created by hezi on 2021/10/20.
//  Copyright © 2021 hezi. All rights reserved.
//

import SwiftUI

struct EmojiArtDocumentView: View {
    @ObservedObject var document: EmojiArtDocument
    
    var body: some View {
        Text("Hello, World!")
    }
}
