//
//  ViewController.m
//  UIDynamic
//
//  Created by hezi on 2021/11/16.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ViewController.h"

@interface CYView : UIView

@property (nonatomic, assign) CGRect redRect;


@property (nonatomic, assign) CGPoint start;
@property (nonatomic, assign) CGPoint end;

@end

@implementation CYView

-(void)drawRect:(CGRect)rect {
    UIBezierPath *patn = [[UIBezierPath alloc] init];
    [patn moveToPoint: self.start];
    [patn addLineToPoint: self.end];
    [patn stroke];
//    [patn moveToPoint: CGPointMake(0, 200)];
//    [patn addLineToPoint: CGPointMake(200, 250)];
//    [[UIBezierPath bezierPathWithRect: self.redRect] stroke];
}

@end


@interface ViewController () <UICollisionBehaviorDelegate>

@property (nonatomic, strong) UIView *redView;
@property (nonatomic, strong) UIView *blueView;

@property (nonatomic, strong) UIDynamicAnimator *animator;
@property (nonatomic, strong) UIAttachmentBehavior *attach;

@end

@implementation ViewController

- (void)loadView {
    self.view = [[CYView alloc] initWithFrame: [UIScreen mainScreen].bounds];
    self.view.backgroundColor = [UIColor whiteColor];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIView *redView = [[UIView alloc] init];
    redView.backgroundColor = [UIColor redColor];
    redView.frame = CGRectMake(100, 100, 100, 100);
    
    [self.view addSubview: redView];
    
//    UIView *blueView = [[UIView alloc] init];
//    blueView.backgroundColor = [UIColor blueColor];
//    blueView.frame = CGRectMake(170, [UIScreen mainScreen].bounds.size.height - 250, 50, 50);
//    [self.view addSubview: blueView];
//
//    self.blueView = blueView;
    self.redView = redView;
    
    // Do any additional setup after loading the view.
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    UITouch *t = touches.anyObject;
    CGPoint p = [t locationInView: t.view];
    
    self.animator = [[UIDynamicAnimator alloc] initWithReferenceView: self.view];
    
    
//    UIPushBehaviorModeContinuous, 持续的推力（越来越大）
//    UIPushBehaviorModeInstantaneous 瞬时的推力（越来越慢）
    
    UIPushBehavior *push = [[UIPushBehavior alloc] initWithItems: @[self.redView] mode: UIPushBehaviorModeContinuous];
    
//    push.magnitude = 1;
    
    CGFloat offsetX = p.x - self.redView.center.x;
    CGFloat offsetY = p.y - self.redView.center.y;
//    push.angle = M_PI;
    push.pushDirection = CGVectorMake(offsetX / 30, offsetY / 30);
    
    [self.animator addBehavior: push];
}
//
//- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//
//    self.animator = [[UIDynamicAnimator alloc] initWithReferenceView: self.view];
//
//    UITouch *t = touches.anyObject;
//    CGPoint p = [t locationInView: t.view];
//
//    self.attach = [[UIAttachmentBehavior alloc] initWithItem: self.redView attachedToAnchor:p];
//    self.attach.length = 100;
//    //频率
//    self.attach.frequency = 0.5;
//    self.attach.damping = 0.5;
//
//    UIGravityBehavior *gravity = [[UIGravityBehavior alloc] initWithItems: @[self.redView]];
//
//    [self.animator addBehavior: gravity];
//    [self.animator addBehavior:self.attach];
//
//}
//
//- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    UITouch *t = touches.anyObject;
//    CGPoint p = [t locationInView: t.view];
//    self.attach.anchorPoint = p;
//
//    __weak ViewController *weakSelf = self;
//    self.attach.action = ^{
//        CYView *view = (CYView *)weakSelf.view;
//        view.start = weakSelf.redView.center;
//        view.end = p;
//        [weakSelf.view setNeedsDisplay];
//    };
//}

//- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    UITouch *t = touches.anyObject;
//    CGPoint p = [t locationInView: t.view];
//
//    UISnapBehavior *snap = [[UISnapBehavior alloc] initWithItem:self.redView snapToPoint: p];
//
//    //减速程度
//    snap.damping = 0;
//
//
//    [self.animator addBehavior: snap];
//
//}

//- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//
//    UIGravityBehavior *gravity = [[UIGravityBehavior alloc] initWithItems: @[self.redView]];
//
//    UICollisionBehavior *collision = [[UICollisionBehavior alloc]initWithItems:@[self.redView, self.blueView]];
//
//    collision.translatesReferenceBoundsIntoBoundary = YES;
//
////    [collision addBoundaryWithIdentifier: @"key" fromPoint: CGPointMake(0, 200) toPoint:CGPointMake(200, 250)];
//
//    [collision addBoundaryWithIdentifier: @"key" forPath: [UIBezierPath bezierPathWithRect: self.blueView.frame]];
////    gravity.angle = M_PI;
////    gravity.gravityDirection = CGVectorMake(1, 1);
////    gravity.magnitude = 10;
//
//    //action 实时监听
//    collision.action = ^{
//        NSLog(@"%@", NSStringFromCGRect(self.redView.frame));
//        CYView *view = (CYView *)self.view;
//        view.redRect = self.redView.frame;
//        [self.view setNeedsDisplay];
//    };
//
//    [self.animator addBehavior: collision];
//    [self.animator addBehavior: gravity];
//}
//
//-(void)collisionBehavior:(UICollisionBehavior *)behavior beganContactForItem:(id<UIDynamicItem>)item withBoundaryIdentifier:(id<NSCopying>)identifier atPoint:(CGPoint)p {
//    NSString *str = (NSString *)identifier;
//    if ([str isEqualToString: @"key"]) {
//
//    }
//}

@end
