//
//  AppDelegate.h
//  UIDynamic
//
//  Created by hezi on 2021/11/16.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

