//
//  ViewController.m
//  autoLayout3
//
//  Created by hezi on 2021/10/28.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
- (IBAction)click:(id)sender;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *redviewTop;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


- (IBAction)click:(id)sender {
    self.redviewTop.constant += 100;
    [UIView animateWithDuration: 0.5 animations:^{
        [self.view layoutIfNeeded];
    }];
}
@end
