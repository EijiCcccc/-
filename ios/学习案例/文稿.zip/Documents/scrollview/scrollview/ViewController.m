//
//  ViewController.m
//  scrollview
//
//  Created by hezi on 2021/10/22.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIScrollView *bgscrollview;
@property (weak, nonatomic) IBOutlet UIImageView *lastImage;
@property (nonatomic, strong) NSArray *array;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    CGRect lastImageFrame = _lastImage.frame;
    self.bgscrollview.contentSize = CGSizeMake(0, CGRectGetMaxY(lastImageFrame));
    // Do any additional setup after loading the view.
    NSArray *arr = [self.array valueForKeyPath:@"title"];
    self.bgscrollview.contentInset = UIEdgeInsetsMake(100, 0, 0, 0);
    
}

-(BOOL)prefersStatusBarHidden {
    return YES;
}

@end
