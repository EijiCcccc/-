//
//  SceneDelegate.h
//  scrollview
//
//  Created by hezi on 2021/10/22.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

