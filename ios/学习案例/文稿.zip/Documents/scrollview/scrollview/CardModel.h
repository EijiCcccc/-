//
//  CardModel.h
//  scrollview
//
//  Created by hezi on 2021/10/22.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CardModel : NSObject

@property (nonatomic, copy) NSString* name1;
@property (nonatomic, copy) NSString* name2;

+ (instancetype)sharedInstance;

- (instancetype)initWithDic: (NSDictionary *)dic;

//+ (instancetype)cardModel: (NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
