//
//  TableViewCell.h
//  scrollview
//
//  Created by hezi on 2021/10/22.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <UIKit/UIKit.h>
#include "CardModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TableViewCell : UITableViewCell

@property (nonatomic, strong) CardModel *model;

@end

NS_ASSUME_NONNULL_END
