//
//  TableViewCell.m
//  scrollview
//
//  Created by hezi on 2021/10/22.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "TableViewCell.h"

@interface TableViewCell ()



@end

@implementation TableViewCell


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
//    self.model {
//        get {}
//    }
//    self.model = xxx {
//        set {}
//    }

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setModel:(CardModel *)model {
    _model = model;
}

@end
