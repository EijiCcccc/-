//
//  CardModel.m
//  scrollview
//
//  Created by hezi on 2021/10/22.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "CardModel.h"

@implementation CardModel

+ (instancetype)sharedInstance {
    static CardModel *cardModel = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        cardModel = [[CardModel alloc] initWithDic:@{}];
    });
    return cardModel;
}

- (instancetype)initWithDic:(NSDictionary *)dic {
    if (self == [super init]) {
        [CardModel sharedInstance];
        [CardModel sharedInstance];
//        [self setValuesForKeysWithDictionary:dic];
    }
    return self;
}
@end
