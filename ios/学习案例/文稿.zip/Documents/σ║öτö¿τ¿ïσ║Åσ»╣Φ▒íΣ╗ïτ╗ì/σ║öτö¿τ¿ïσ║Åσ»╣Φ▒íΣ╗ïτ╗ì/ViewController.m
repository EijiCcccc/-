//
//  ViewController.m
//  应用程序对象介绍
//
//  Created by hezi on 2021/11/8.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
- (IBAction)buttonClick:(id)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


- (IBAction)buttonClick:(id)sender {
    //修改程序消息数量
//    UIApplication *app = [UIApplication sharedApplication];
    
    
//    UIUserNotificationCategory *category = [[UIUserNotificationCategory alloc] init];
//    NSSet *set = [NSSet setWithObject: category];
//    UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes: UIUserNotificationTypeBadge categories: set];
//    [app registerUserNotificationSettings: settings];
//    app.applicationIconBadgeNumber = 10;
//
//    app.networkActivityIndicatorVisible = YES;
//
//    app.statusBarHidden = YES;
}

@end
