//
//  AppDelegate.m
//  手动创建window
//
//  Created by hezi on 2021/11/9.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "AppDelegate.h"
#import "HMViewController.h"
#import "HMTableTableViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame: [UIScreen mainScreen].bounds];
 
    //  通过代码创建控制器
//    HMTableTableViewController *vc = [[HMTableTableViewController alloc] init];
//    self.window.rootViewController = vc;
    
    //通过storyboard加载
//    UIStoryboard  *board = [UIStoryboard storyboardWithName: @"HMStoryboard" bundle:nil];
//    UIViewController *vc = [board instantiateViewControllerWithIdentifier: @"red"];
//    self.window.rootViewController = vc;
    
//    UIViewController *vc = [[HMViewController alloc]
//                            initWithNibName: @"HMViewController" bundle:nil];
    
    UIViewController *vc = [[HMViewController alloc] init];
    self.window.rootViewController = vc;
    //通过xib加载
    [self.window makeKeyAndVisible];
    // Override point for customization after application launch.
    return YES;
}

#pragma mark - UISceneSession lifecycle

//
//- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options {
//    // Called when a new scene session is being created.
//    // Use this method to select a configuration to create the new scene with.
//    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
//}
//
//
//- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions {
//    // Called when the user discards a scene session.
//    // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
//    // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
//}


@end
