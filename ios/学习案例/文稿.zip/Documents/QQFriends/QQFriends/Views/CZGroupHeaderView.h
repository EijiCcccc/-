//
//  CZGroupHeaderView.h
//  QQFriends
//
//  Created by hezi on 2021/10/26.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class CZGroupHeaderView;
@protocol CZGroupHeaderViewDelegate <NSObject>

- (void)groupHeaderViewDidClickTitleButton:(CZGroupHeaderView *)CZGroupHeaderView;

@end

@class CZGroup;
@interface CZGroupHeaderView : UITableViewHeaderFooterView
@property (nonatomic, strong) CZGroup *group;

+(instancetype)groupHeaderWithTableView: (UITableView *)tableView;
@property (nonatomic, weak) id<CZGroupHeaderViewDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
