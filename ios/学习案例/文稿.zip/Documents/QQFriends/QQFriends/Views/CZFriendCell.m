//
//  CZFriendCell.m
//  QQFriends
//
//  Created by hezi on 2021/10/26.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "CZFriendCell.h"

@implementation CZFriendCell

+(instancetype)friendCellWithTableView:(UITableView *)tableView {
    static NSString *ID = @"friend_cell";
    CZFriendCell *cell = [tableView dequeueReusableCellWithIdentifier: ID];
    if (cell == nil) {
        cell = [[CZFriendCell alloc] initWithStyle: UITableViewCellStyleSubtitle reuseIdentifier: ID];
    }
    return  cell;
}

-(void)setFriendModel:(CZFriends *)friendModel {
    _friendModel = friendModel;
    self.imageView.image = [UIImage imageNamed: friendModel.icon];
    self.textLabel.text = friendModel.name;
    self.detailTextLabel.text = friendModel.intro;
    
    self.textLabel.textColor = friendModel.isVip ? [UIColor redColor] : [UIColor whiteColor];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
