//
//  CZGroupHeaderView.m
//  QQFriends
//
//  Created by hezi on 2021/10/26.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "CZGroupHeaderView.h"
#import "CZGroup.h"

@interface CZGroupHeaderView ()

@property (nonatomic, weak) UIButton *btnGroupTitle;
@property (nonatomic, weak) UILabel *count;

@end

@implementation CZGroupHeaderView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(void)setGroup:(CZGroup *)group {
    // 初始化数据
    _group = group;
    
    [self.btnGroupTitle setTitle:group.name forState:UIControlStateNormal];
    
    self.count.text = [NSString stringWithFormat:@"%d / %lu", group.online, group.friends.count];
    
    if (self.group.isVisible) {
        self.btnGroupTitle.imageView.transform = CGAffineTransformMakeRotation(M_PI);
    } else {
        self.btnGroupTitle.imageView.transform = CGAffineTransformMakeRotation(0);
    }
}

+(instancetype)groupHeaderWithTableView:(UITableView *)tableView {
    
    static NSString *ID = @"group_header_view";
    CZGroupHeaderView *headerView = [tableView dequeueReusableHeaderFooterViewWithIdentifier: ID];
    if (headerView == nil) {
        headerView = [[CZGroupHeaderView alloc] initWithReuseIdentifier:ID];
    }
    return headerView;
}

-(instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithReuseIdentifier:reuseIdentifier]) {
        UIButton *btnGroupTitle = [[UIButton alloc] init];
    
        [btnGroupTitle setImage: [UIImage imageNamed: @"gray_down_indicator"] forState:UIControlStateNormal];
        btnGroupTitle.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        btnGroupTitle.contentEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
        btnGroupTitle.titleEdgeInsets = UIEdgeInsetsMake(0, 20, 0, 0);
        
        [btnGroupTitle addTarget:self action:@selector(btnGroupTitleClick) forControlEvents:UIControlEventTouchUpInside];
        btnGroupTitle.imageView.contentMode = UIViewContentModeCenter;
        btnGroupTitle.imageView.clipsToBounds = NO;
        [self.contentView addSubview: btnGroupTitle];
        self.btnGroupTitle = btnGroupTitle;
        
        UILabel *count = [[UILabel alloc] init];
        [self.contentView addSubview: count];
        self.count = count;
    }
    return  self;
}

-(void)layoutSubviews {
    [super layoutSubviews];
    self.btnGroupTitle.frame = self.bounds;
    CGFloat lbW = 100;
    CGFloat lbH = self.bounds.size.height;
    CGFloat lbX = self.bounds.size.width - 10 - lbW;
    CGFloat lbY = 0;
    self.count.frame = CGRectMake(lbX, lbY, lbW, lbH);
}

-(void)btnGroupTitleClick {
    self.group.visible = !self.group.isVisible;
    
    if ([self.delegate respondsToSelector:@selector(groupHeaderViewDidClickTitleButton:)]) {
        [self.delegate groupHeaderViewDidClickTitleButton: self];
    }
}

@end
