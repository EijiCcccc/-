//
//  CZFriendCell.h
//  QQFriends
//
//  Created by hezi on 2021/10/26.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CZFriends.h"

NS_ASSUME_NONNULL_BEGIN
//@class CZFriends;
@interface CZFriendCell : UITableViewCell

+(instancetype)friendCellWithTableView: (UITableView *)tableView;

@property (nonatomic, strong) CZFriends *friendModel;

@end

NS_ASSUME_NONNULL_END
