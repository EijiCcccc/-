//
//  CZFriends.h
//  QQFriends
//
//  Created by hezi on 2021/10/26.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CZFriends : NSObject

@property (nonatomic, copy) NSString *icon;

@property (nonatomic, copy) NSString * name;

@property (nonatomic, copy) NSString * intro;

@property (nonatomic, assign, getter=isVip) BOOL vip;

-(instancetype)initWithDic: (NSDictionary *)dic;

+(instancetype)friendsWithDic: (NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
