//
//  CZGroup.m
//  QQFriends
//
//  Created by hezi on 2021/10/26.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "CZGroup.h"
#import "CZFriends.h"

@implementation CZGroup

-(instancetype)initWithDic:(NSDictionary *)dic {
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary:dic];
        

        NSMutableArray *arrayModel = [NSMutableArray array];
        for (NSDictionary *dic_sub in self.friends) {
            CZFriends *friendsModel = [CZFriends friendsWithDic:dic_sub];
            [arrayModel addObject:friendsModel];
        }
        self.friends = arrayModel;
    }
    return  self;
}

+(instancetype)groupWithDic:(NSDictionary *)dic {
    return  [[self alloc] initWithDic: dic];
}

@end
