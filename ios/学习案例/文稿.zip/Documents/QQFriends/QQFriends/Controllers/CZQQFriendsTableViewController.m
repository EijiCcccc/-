//
//  CZQQFriendsTableViewController.m
//  QQFriends
//
//  Created by hezi on 2021/10/26.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "CZQQFriendsTableViewController.h"
#import "CZGroup.h"
#import "CZFriends.h"
#import "CZFriendCell.h"
#import "CZGroupHeaderView.h"

@interface CZQQFriendsTableViewController () <CZGroupHeaderViewDelegate>

@property (nonatomic, strong) NSArray* groups;

@end

@implementation CZQQFriendsTableViewController

-(void)groupHeaderViewDidClickTitleButton:(CZGroupHeaderView *)groupHeaderView {
    
    NSIndexSet *index = [NSIndexSet indexSetWithIndex: groupHeaderView.tag];
    
    [self.tableView reloadSections:index withRowAnimation: UITableViewRowAnimationFade];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.sectionHeaderHeight = 44;
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

#pragma mark 懒加载

-(NSArray *)groups {
    if (_groups == nil) {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"Property List.plist" ofType:nil];
        NSArray *array = [NSArray arrayWithContentsOfFile:path];
        
        NSMutableArray *arrayModels = [NSMutableArray array];
        for (NSDictionary *dic in array) {
            CZGroup *groups = [CZGroup groupWithDic: dic];
            [arrayModels addObject: groups];
        }
        _groups = arrayModels;
    }
    return _groups;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.groups.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    CZGroup *group = self.groups[section];
    if (group.isVisible) {
        return group.friends.count;
    } else {
        return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    CZGroup *group = self.groups[indexPath.section];
    CZFriends *friends = group.friends[indexPath.row];
    
    CZFriendCell *cell = [CZFriendCell friendCellWithTableView: tableView];
    
    cell.friendModel = friends;
    
    return cell;
}

//-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
//    CZGroup *group = self.groups[section];
//    return group.name;
//}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    CZGroup *group = self.groups[section];
    
    CZGroupHeaderView *headerView = [CZGroupHeaderView groupHeaderWithTableView:tableView];
    
    headerView.delegate = self;
    
    headerView.tag = section;
    
    headerView.group = group;
    
    
    return headerView;
}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark 隐藏状态栏
-(BOOL)prefersStatusBarHidden {
    return YES;
}

@end
