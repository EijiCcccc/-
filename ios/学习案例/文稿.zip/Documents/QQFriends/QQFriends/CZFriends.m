//
//  CZFriends.m
//  QQFriends
//
//  Created by hezi on 2021/10/26.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "CZFriends.h"

@implementation CZFriends

-(instancetype)initWithDic:(NSDictionary *)dic {
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary:dic];
    }
    return self;
}

+(instancetype)friendsWithDic:(NSDictionary *)dic {
    return  [[self alloc] initWithDic: dic];
}

@end
