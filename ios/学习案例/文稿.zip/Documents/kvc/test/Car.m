//
//  Car.m
//  test
//
//  Created by hezi on 2021/11/2.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "Car.h"

@implementation Car

-(void)setSpeed: (int) speed{
    _speed = speed;
}

-(int)speed {
    return _speed;
}

-(void)run {
    NSLog(@"时速为%d", _speed);
}

-(void)dealloc {
    NSLog(@"car%d dealloc", _speed);
}

@end
