//
//  Person.h
//  test
//
//  Created by hezi on 2021/11/2.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Car.h"

NS_ASSUME_NONNULL_BEGIN

@interface Person : NSObject {
    Car *_car;
    int _age;
    NSString *_name;
}

//@propery(参数1, 参数2)
// 与多线程相关的 atomic nonatomic
    //   如果写atomic， 会在生成的时候加上线程安全锁 特点：安全，效率低
    //   同时改写读取数据时，会加锁，使用队列
    //   如果写nonatomic， 会在生成的时候不会加上线程安全锁 特点：不安全，效率高
// 与生成setter方法相关  assign  retain
    // assign： 默认值，生成setter方法直接赋值
    // retain： 生成的setter方法实现就是标准的mrc内存管理代码
    //    -(void)setName: (NSString *)name {
    //        if (_name != name) {
    //          [_name release];
    //          [name retain];
    //        }
    //
    //    }
    // 当属性的类型是OC对象类型的时候，就使用retain, 当属性的类型是非OC对象的时候，使用assign
    // retain 只生成标准的setter为MRC内存管理代码，不会自动给delloc添加release代码
// 与生成只读，读写的参数 readonly readwrite
    // readwrite： 默认值，生成setter，getter
    // readonly： 只生成getter，不会生成setter
// 与生成getter setter方法名字相关的参数  getter setter
    //默认情况下 ,@property 生成的getter，setter为标准代码
    //getter, setter 修改@property生成的名字

@property (nonatomic, assign) int age;
@property (nonatomic, strong, readonly) NSString *name1;
@property (nonatomic, strong, getter=get, setter=set:) NSString *name2;
@property (weak) NSString *name3;

-(void)setCar: (Car *)car;
-(Car *)car;

-(void)setAge: (int )age;
-(int)age;

-(void)setName: (NSString *)name;
-(NSString *)name;

-(void)drive;

@end

NS_ASSUME_NONNULL_END
