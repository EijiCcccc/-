//
//  Car.h
//  test
//
//  Created by hezi on 2021/11/2.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Car : NSObject
{
    int _speed;
}

-(void)setSpeed: (int)speed;
-(int)speed;

-(void)run;

@end

NS_ASSUME_NONNULL_END
