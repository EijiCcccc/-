//
//  Person.m
//  test
//
//  Created by hezi on 2021/11/2.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "Person.h"


@implementation Person {
    NSString *_name3;
}

- (NSString *)name3 {
    return _name3;
}

- (void)setName3:(NSString *)name3 {
    _name3 = name3;
}

-(void)setCar:(Car *)car {
    if(_car != car) { //说明新旧对象不是同一个的对象
        _car = car;
    }
}

- (Car *)car {
    return _car;
}

-(void)setName: (NSString *)name {
}
-(NSString *)name {
    return _name;
}

-(void)setAge:(int)age {
    _age = age;
}

- (int )age {
    return _age;
}

- (void)drive {
    NSLog(@"gogogog");
    [_car run];
}

-(void)dealloc {
    NSLog(@"人挂了");
}

@end
