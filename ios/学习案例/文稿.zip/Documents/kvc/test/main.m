//
//  main.m
//  test
//
//  Created by hezi on 2021/11/2.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"

int main(int argc, const char * argv[]) {
    
    
    Person *p1 = [Person new];
    p1.name2 = @"b";
    NSLog(@"%@", p1.get);
    
    [p1 set:@"a"];
    NSLog(@"%@", [p1 get]);
    
    Car *bmw = [Car new];
    p1.car = bmw;
    
    
//    Person *p1 = [Person new];
//    Car *bmw = [Car new];
//    bmw.speed = 100;
//    p1.car = bmw;
//
//    [p1 drive];
//
//    [bmw release];
//
//    bmw.speed = 200;
//    p1.car = bmw;
//
//    [p1 release];
    
    
    
    
//    Person *p1 = [Person new]; //1
//    Car *bmw = [Car new]; //1
//    bmw.speed = 100;
//    p1.car = bmw; // 2
//
//    [p1 drive];
//
//    [bmw release];
//
//    [p1 drive];
//
//    [p1 release];
    
    
    
    
//    Person *p1 = [Person new];
//
//    Car *bmw = [Car new];
//    bmw.speed = 200;
//    p1.car = bmw;
//
//    Car *benz = [Car new];
//    benz.speed = 400;
//    p1.car = benz;
//
//    [bmw release];
//    [benz  release];
//    [p1 release];

    return 0;
}
