//
//  main.m
//  协议
//
//  Created by hezi on 2021/11/4.
//  Copyright © 2021 hezi. All rights reserved.
//

/*
1.协议：protocol
 作用：1）专门用来声明一大堆方法（不能声明属性，也不能实现方法，只能用来写方法声明）
    2）只要某个类遵守了这个协议，就可以拥有这个协议中的所有方法声明，而不用自己定义
*/

#import <Foundation/Foundation.h>
#import "Dog.h"
#import "MyProtocol.h"
#import "YourProtocol.h"
#import "Pig.h"

int main(int argc, const char * argv[]) {
//    @autoreleasepool {
//        // insert code here...
//        NSLog(@"Hello, World!");
//    }
//    Dog *dog = [Dog new];
//    [dog run];
//    [dog eat];
//    [dog sleep];
    Dog<MyProtocol, YourProtocol> *dog = [Pig new];
    return 0;
}
