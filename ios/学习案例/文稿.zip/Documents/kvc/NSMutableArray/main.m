//
//  main.m
//  NSMutableArray
//
//  Created by hezi on 2021/11/5.
//  Copyright © 2021 hezi. All rights reserved.
//

/*
1.NSMutableArray是NSArray的子类
    1)只能存储OC对象
    2)可以新增和删除，其他用法与NSArray一样
 
2.NSMutableArray的创建
    
    不能使用 NSMutableArray *arr1 = @[@"jack", @"rose", @"zzz"];创建
    同NSMutableString 和 NSString
 
3.新增元素
 - (void)addObject:(ObjectType)anObject;

4.将另外一个数组的所有元素添加到该数组中
- (void)addObjectsFromArray:(NSArray<ObjectType> *)otherArray;
 
5.指定下标中插入一个元素
- (void)insertObject:(ObjectType)anObject atIndex:(NSUInteger)index;
 
6.删除下标的元素

 - (void)removeObjectAtIndex:(NSUInteger)index;

 7.删除指定元素
 - (void)removeObject:(ObjectType)anObject;
 
 8.删除指定范围中指定的元素
 - (void)removeObject:(ObjectType)anObject inRange:(NSRange)range;
 
 9删除最后一个元素
 - (void)removeLastObject;
 10删除所有元素
 - (void)removeAllObjects;
 
---------------------------------------
 1.任意的指针其实可以指向任意的对象，编译不会报错，只会警告
 2.当调用指针类型特有的方法时，会报错
 
 */

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    NSMutableArray *arr1 = [NSMutableArray arrayWithObjects:@"jack", @"rose", @"zzz", nil];
    [arr1 addObject: @"xxxx"];
    NSArray *arr = @[@"z", @"x", @"c"];
    [arr1 insertObject: @"q" atIndex: 0];
    [arr1 addObject: arr];
    [arr1 addObjectsFromArray: arr];
    
    [arr1 removeObjectAtIndex: 0];
    
    [arr1 removeObject: @"xxxx"];
    
    [arr1 removeObject: @"jack" inRange: NSMakeRange(0, 3)];
    
    [arr1 removeLastObject];
    [arr1 removeAllObjects];
    NSLog(@"%@", arr1);
    return 0;
}
