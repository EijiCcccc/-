//
//  main.m
//  NSDictionary
//
//  Created by hezi on 2021/11/5.
//  Copyright © 2021 hezi. All rights reserved.
//

/*
 1.通过别名来找，而不是通过下标来找存储在数组中的数据，
    这种存储数据的方式，叫做 键值对 的存储方式
    key-value
 2.NSDictionary 与 NSMutableDictionary
    1)他们是数组，他们就是以键值对的形式存储数据
 3.NSDictinary 字典数组
    1.创建对象
    无意义：
         NSDictionary *dic = [NSDictionary new];
         NSDictionary *dic = [NSDictionary dictionary];
         NSDictionary *dic = [[NSDictionary alloc] init];
    一般创建方式：
  NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"jack", @"name", @"街道", @"address", nil];
    简要方式：
    NSDictionary *dic = @{@"name": @"rose", @"age": @"18"};
 
5.遍历字典
    for (id item in dic) {
        NSLog(@"%@", dic[item]);
    }
 
 
 [dic enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        NSLog(@"%@,   %@", key ,obj);
    }];
 
 6.字典数组存储数据的原理
    存储数据的时候，会根据key和数组的长度做一个哈希算法， 将这个键值对存储在改下标
    取值的时候，也是根据key和数组的长度做一个哈希算法算出键值对的下标，然后通过下标取值
 
 与NSArray 对比
    1）NSArray 挨个挨个按顺序存储
    2）存的效率： NSArray 高
        取的时候，若全部取出，NSArray效率高
                若取出指定的元素，NSDictionary快
 */

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"jack", @"name", @"街道", @"address", nil];
    NSDictionary *dic = @{
        @"name": @"rose",
        @"age": @"18",
        @"address": @"adsasda",
        @"height": @"181",
    };
//    NSString *name = dic[@"age"];
//    NSString *name1 = [dic objectForKey: @"name"];
    NSLog(@"%@", dic);
//    NSLog(@"%@", name);
//    NSLog(@"%@", name1);
//
//    [dic enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
//        NSLog(@"%@,   %@", key ,obj);
//    }];
//    for (id item in dic) {
//        NSLog(@"%@", dic[item]);
//    }
//    @autoreleasepool {
//        // insert code here...
//        NSLog(@"Hello, World!");
//    }
    return 0;
}
