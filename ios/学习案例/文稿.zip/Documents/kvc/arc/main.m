//
//  main.m
//  arc
//
//  Created by hezi on 2021/11/3.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"

int main(int argc, const char * argv[]) {
    Person *p1 = [Person new];
    Car *c1 = [Car new];
    p1.car = c1;
    c1.person = p1;
    
    return 0;
}
