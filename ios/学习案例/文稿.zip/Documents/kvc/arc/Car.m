//
//  Car.m
//  arc
//
//  Created by hezi on 2021/11/3.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "Car.h"

@implementation Car

-(void)dealloc {
    NSLog(@"car die");
}

@end
