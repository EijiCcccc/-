//
//  Car.h
//  arc
//
//  Created by hezi on 2021/11/3.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Person;
NS_ASSUME_NONNULL_BEGIN

@interface Car : NSObject

@property (nonatomic, weak) Person *person;

@end

NS_ASSUME_NONNULL_END
