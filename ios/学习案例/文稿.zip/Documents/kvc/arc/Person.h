//
//  Person.h
//  arc
//
//  Created by hezi on 2021/11/3.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Car.h"

NS_ASSUME_NONNULL_BEGIN

@interface Person : NSObject

@property (nonatomic, strong) Car *car;

@end

NS_ASSUME_NONNULL_END
