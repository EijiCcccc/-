//
//  main.m
//  NSFileManager
//
//  Created by hezi on 2021/11/8.
//  Copyright © 2021 hezi. All rights reserved.
//
/*
 1.NSFileManger是foundation框架提供一个类
 用来操作磁盘上的文件，对文件进行创建，删除，复制，拷贝 移动
 2调用这个类的类方法，defaultManager 就可以得到这个类的单例对象
    NSFileManager *manager = [NSFileManager defaultManager];
3.文件判断方法
    判断文件是否存在
 - (BOOL)fileExistsAtPath:(NSString *)path;
    判断文件是否存在并且判断文件路径还是文件夹路径
 - (BOOL)fileExistsAtPath:(NSString *)path isDirectory:(nullable BOOL *)isDirectory;
    判断文件是否可读
 - (BOOL)isReadableFileAtPath:(NSString *)path;
    判断文件是否可写
 - (BOOL)isWritableFileAtPath:(NSString *)path;
    判断文件是否有权限可以删除
 - (BOOL)isDeletableFileAtPath:(NSString *)path;
 4.获取信息
    获取指定文件或者文件夹的属性信息
 - (nullable NSDictionary<NSFileAttributeKey, id> *)attributesOfItemAtPath:(NSString *)path error:(NSError **)error API_AVAILABLE(macos(10.5), ios(2.0), watchos(2.0), tvos(9.0));
    获取指定路径下所有的文件和目录，所有的子目录的目录和文件
 - (nullable NSArray<NSString *> *)subpathsAtPath:(NSString *)path;
    获取指定路径下所有的文件和目录，不包括子目录的子目录
 - (nullable NSArray<NSString *> *)contentsOfDirectoryAtPath:(NSString *)path error:(NSError **)error API_AVAILABLE(macos(10.5), ios(2.0), watchos(2.0), tvos(9.0));
 5.创建
    文件目录的创建
 - (BOOL)createFileAtPath:(NSString *)path contents:(nullable NSData *)data attributes:(nullable NSDictionary<NSFileAttributeKey, id> *)attr;
    文件夹创建
    第一个参数：路径
    第二个参数： YES做一路创建，NO就不会做一路创建
    第三个参数：指定属性，nil为默认属性
 - (BOOL)createDirectoryAtPath:(NSString *)path withIntermediateDirectories:(BOOL)createIntermediates attributes:(nullable NSDictionary<NSFileAttributeKey, id> *)attributes error:(NSError **)error API_AVAILABLE(macos(10.5), ios(2.0), watchos(2.0), tvos(9.0));
    拷贝文件
 - (BOOL)copyItemAtPath:(NSString *)srcPath toPath:(NSString *)dstPath error:(NSError **)error API_AVAILABLE(macos(10.5), ios(2.0), watchos(2.0), tvos(9.0));
    移动文件,重命名(将文件移动到原目录并改名),剪切
 - (BOOL)moveItemAtPath:(NSString *)srcPath toPath:(NSString *)dstPath error:(NSError **)error API_AVAILABLE(macos(10.5), ios(2.0), watchos(2.0), tvos(9.0));
    删除文件
 - (BOOL)removeItemAtPath:(NSString *)path error:(NSError **)error API_AVAILABLE(macos(10.5), ios(2.0), watchos(2.0), tvos(9.0));

 */

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
//    @autoreleasepool {
//        // insert code here...
//        NSLog(@"Hello, World!");
//    }
    NSFileManager *manager = [NSFileManager defaultManager];
    NSString *path = @"/Users/hezi/Desktop/cao/a.txt";
    NSString *path1 = @"/Users/hezi/Desktop/a.txt";
    
    [manager removeItemAtPath: path error: nil];
    
//    [manager moveItemAtPath: path1 toPath: path error:nil];
//    [manager copyItemAtPath: path1 toPath: path error: nil];
    
    
//    [manager createDirectoryAtPath: path withIntermediateDirectories: NO attributes: nil error: nil];
//
    
    //存储在磁盘上的任何文件都是以二进制的形式存储
    //NSData对象撞门用来保存二进制数据的
//    NSString *str = @"歪哦就送阿福iu啊函数";
//    NSData *data = [str dataUsingEncoding: NSUTF8StringEncoding];
//    BOOL res = [manager createFileAtPath: path contents: data attributes: nil];
//
//    NSArray *arry = [manager subpathsAtPath: path];
//    NSArray *array = [manager contentsOfDirectoryAtPath: path error: nil];
//
//    for (NSString *str in array) {
//        NSLog(@"%@", str);
//    }
//    NSDictionary *dic = [manager attributesOfItemAtPath: path error: nil];
//    NSLog(@"%@", arry);
    
//    BOOL res = [manager isWritableFileAtPath: path];
//    BOOL res = [manager isReadableFileAtPath: path];
    
//    BOOL flag = NO;
//    BOOL res = [manager fileExistsAtPath: path isDirectory: &flag];
//    //判断是否存在
//    if (res == YES){
//        if (flag == YES) {
//            // 说明给定的路径是一个文件夹路径
//            NSLog(@"路径是一个文件夹路径");
//
//        } else {
//            NSLog(@"是一个文件路径");
//            // 说明是一个文件路径
//        }
//    }
    return 0;
}
