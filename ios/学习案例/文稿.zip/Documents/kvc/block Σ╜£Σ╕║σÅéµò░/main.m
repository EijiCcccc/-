//
//  main.m
//  block 作为参数
//
//  Created by hezi on 2021/11/4.
//  Copyright © 2021 hezi. All rights reserved.
//

/*
 1.block是一个数据类型，可以作为函数的参数
 2.如何为函数定义block类型的参数
    a.就是在小括弧中声明一个指定格式的block变量
    b.使用typedef定义
 3.如何使用带block参数的函数
    传入一个和参数block要求的代码段
    先声明一个block变量然后传入函数
4将block作为函数的参数可以实现
    可以将调用者自己写的一段代码，传入函数内部执行
 传入
 */

#import <Foundation/Foundation.h>
typedef void (^NewType)();

void test(NewType block1) {
    NSLog(@"````````");
    block1();
    NSLog(@"````````");
}

void test1(int num) {
    
}

void test2(int (^paramsBlock)(int num1, int num2)) {
    int sum = paramsBlock(1, 3);
    NSLog(@"%d", sum);
}

int main(int argc, const char * argv[]) {
//    @autoreleasepool {
//        // insert code here...
//        NSLog(@"Hello, World!");
//    }
    test(^{
        NSLog(@"test");
    });
    
    test2(^int(int num1, int num2) {
        return num1 + num2;
    });
    
    test1(10);
    return 0;
}
