//
//  Student.m
//  kvc
//
//  Created by hezi on 2021/11/2.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "Student.h"

@implementation Student

-(void)study {
    
}

@end
