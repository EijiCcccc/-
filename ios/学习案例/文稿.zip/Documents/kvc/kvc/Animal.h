//
//  Person.h
//  kvc
//
//  Created by hezi on 2021/10/27.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Dog.h"
NS_ASSUME_NONNULL_BEGIN

@interface Animal : NSObject {
    float _wight;
    @protected
    NSString *_name;
    @private
    NSString * _age;
}
@property float wight;
@property (nonatomic, strong) Dog* dog;
+(void)say;
+(void)say1;
-(void)log;
-(void) aa;
@end

NS_ASSUME_NONNULL_END
