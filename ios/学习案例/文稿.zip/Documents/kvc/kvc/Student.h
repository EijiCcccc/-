//
//  Student.h
//  kvc
//
//  Created by hezi on 2021/11/2.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "Animal.h"

typedef struct{
    NSString *a;
    int b;
    int c;
} Data;

@interface Student : Animal {
    @public
    Data studentData;
}

@property (nonatomic, copy) NSString*studentName;

-(void)study;

@end
