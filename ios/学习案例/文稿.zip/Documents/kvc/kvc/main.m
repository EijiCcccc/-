//
//  main.m
//  kvc
//
//  Created by hezi on 2021/10/27.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Animal.h"
#import "Student.h"
#import <objc/runtime.h>

void test( NSString*a, NSString *b) {
    NSLog(@"%@, %@", a, b);
};

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Animal *person = [Animal new];
        person.wight = 50.12;
        NSLog(@"widht == %f", person.wight);
        SEL s1 = @selector(aa);
        #pragma clang diagnostic push
        #pragma clang diagnostic ignored "-Warc-performSelector-leaks"
        [person performSelector: s1];
        #pragma clang diagnostic pop
//        person->studentData = (Data){@"a", 2, 3};
//        NSLog(@"%@", person);
//        [person study];
//        Class p1 = [Person class];
//        Class p2 = [person class];
//        NSLog(@"p1: %p  p2: %p", &p1, &p2);
        
//        person.name = @"a";


    }
    return 0;
}
