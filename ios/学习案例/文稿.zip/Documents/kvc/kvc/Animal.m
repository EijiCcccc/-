//
//  Person.m
//  kvc
//
//  Created by hezi on 2021/10/27.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "Animal.h"

@interface Animal ()
@end

@implementation Animal
@synthesize wight = _wight;
+(void)say{
    NSLog(@"111");
}

+(void)say1{
    [self say];
    NSLog(@"123");
}

- (void)log {
//    NSLog(@"%@", _name);
}
-(void)aa {
    NSLog(@"aaaaa");
}
@end
