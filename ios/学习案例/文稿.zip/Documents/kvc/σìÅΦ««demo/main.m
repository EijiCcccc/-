//
//  main.m
//  协议demo
//
//  Created by hezi on 2021/11/4.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Boy.h"
#import "Gril.h"
#import <limits.h>

int main(int argc, const char * argv[]) {
    Boy *boy = [Boy new];
    boy.age = 18;
    boy.money = INT32_MAX;
    boy.name = @"aa";
    
    Gril *gril = [Gril new];
    gril.name = @"bb";
    
    boy.grilFriend = boy;
    
    [boy talk];
    
    return 0;
}
