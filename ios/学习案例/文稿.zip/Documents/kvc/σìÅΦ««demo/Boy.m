//
//  Boy.m
//  协议demo
//
//  Created by hezi on 2021/11/4.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "Boy.h"

@implementation Boy

-(void)talk {
    NSLog(@"talk");
    [_grilFriend wash];
    [_grilFriend cook];
}


- (void)cook {
    NSLog(@"🐶");
}

- (void)wash {
    NSLog(@"🐶");
}

@end
