//
//  Gril.m
//  协议demo
//
//  Created by hezi on 2021/11/4.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "Gril.h"

@implementation Gril


- (void)cook {
    NSLog(@"cook");
}

- (void)wash {
    NSLog(@"wash");
}


@end
