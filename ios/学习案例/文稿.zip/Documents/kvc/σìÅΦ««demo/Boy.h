//
//  Boy.h
//  协议demo
//
//  Created by hezi on 2021/11/4.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GFProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface Boy : NSObject <GFProtocol>

@property (nonatomic, strong) NSString *name;
@property (nonatomic, assign) int age;
@property (nonatomic, assign) int money;
@property (nonatomic, strong) id<GFProtocol> grilFriend;

-(void)talk;

@end

NS_ASSUME_NONNULL_END
