//
//  main.m
//  NSArray
//
//  Created by hezi on 2021/11/5.
//  Copyright © 2021 hezi. All rights reserved.
//

/*
 1.C语言中的数组
    a.储存多个数据
    b.类型相同
    c.长度固定
    d.每1个元素都是紧密相连的
 2.NSArray
    1)是Foundation框架中的一个类，这个类的对象是用来储存多个数据的，具备数组的功能
    2）特点：
        a.只能储存OC对象，任意的OC对象
        b.长度固定，一旦NSArray数组创建完毕之后，元素的长度固定，无法新增，无法删除元素
        c.每一个元素紧密相连，都有一个自己的下标
        d.元素的类型是id类型
3.NSArray创建
    1）是一个类，创建对象
 + (instancetype)array;
 + (instancetype)arrayWithObject:(ObjectType)anObject;
 + (instancetype)arrayWithObjects:(const ObjectType _Nonnull [_Nonnull])objects count:(NSUInteger)cnt;
 + (instancetype)arrayWithObjects:(ObjectType)firstObj, ... NS_REQUIRES_NIL_TERMINATION;
 + (instancetype)arrayWithArray:(NSArray<ObjectType> *)array;
 - (instancetype)initWithObjects:(ObjectType)firstObj, ... NS_REQUIRES_NIL_TERMINATION;
 - (instancetype)initWithArray:(NSArray<ObjectType> *)array;
 - (instancetype)initWithArray:(NSArray<ObjectType> *)array copyItems:(BOOL)flag;
 - (nullable NSArray<ObjectType> *)initWithContentsOfURL:(NSURL *)url error:(NSError **)error  API_AVAILABLE(macos(10.13), ios(11.0), watchos(4.0), tvos(11.0));
 + (nullable NSArray<ObjectType> *)arrayWithContentsOfURL:(NSURL *)url error:(NSError **)error API_AVAILABLE(macos(10.13), ios(11.0), watchos(4.0), tvos(11.0)) NS_SWIFT_UNAVAILABLE("Use initializer instead");
 NSArray *arr2 = @[p1, p2, p3, p4, p5];
 
 4.NSArray的使用
    1）在NSLog中可以使用%@直接打印
    2）无法储存非OC对象，不能存储基本数据类型
        nil的本质就是0，所以无法储存到NSArray中
 5.取出NSArray中的值
    1)使用下标[]
        NSLog(@"%@", arr1[0]);
    2）- (ObjectType)objectAtIndex:(NSUInteger)index;
 
 6常用方法
    1) 数组长度
        @property (readonly) NSUInteger count;
    2）判断数组中是否包含某个元素
        - (BOOL)containsObject:(ObjectType)anObject;
    3) 取第一个元素
        @property (nullable, nonatomic, readonly) ObjectType firstObject API_AVAILABLE(macos(10.6), ios(4.0), watchos(2.0), tvos(9.0));
        与arr[0]的区别，
        如果数组中没有元素，arr[0]报错，firstObject 为nil
    4) 取最后一个元素
        @property (nullable, nonatomic, readonly) ObjectType lastObject;
    5)查找元素第一次出现的下标
        - (NSUInteger)indexOfObject:(ObjectType)anObject;
        如果没有找到，返回的是NSUInteger的最大值

 7 遍历元素
    1.for (int i = 0; i < arr1.count; i++) {
        NSLog(@"%@", arr1[i]);
    }
    2.增强for循环
        声明在for()中的变量叫迭代变量
        将数组中的第一个元素赋值给迭代变量，执行循环体
        迭代的类型需要和数组中元素的类型一致，当NSArray数组中存储的不一致，迭代变量的类型建议使用id类型
    for (Person *p in arr1) {
        NSLog(@"%@", p);
    }
    3.使用block遍历
     - (void)enumerateObjectsUsingBlock:(void (NS_NOESCAPE ^)(ObjectType obj, NSUInteger idx, BOOL *stop))block API_AVAILABLE(macos(10.6), ios(4.0), watchos(2.0), tvos(9.0));
 
 8 数组与字符串的2个方法
 将数组中的元素连接起来组成一个新的字符串
 - (NSString *)componentsJoinedByString:(NSString *)separator;
 将字符串进行分割，返回一个数组
 - (NSArray<NSString *> *)componentsSeparatedByString:(NSString *)separator;
 
 9.将数组的信息保存起来
 
 
 */

#import <Foundation/Foundation.h>
#import "Person.h"

int main(int argc, const char * argv[]) {
    Person *p1 = [Person new];
    Person *p2 = [Person new];
    Person *p3 = [Person new];
    Person *p4 = [Person new];
    Person *p5 = [Person new];
//    NSArray *arr1 = [NSArray arrayWithObjects: p1, p2, p3, p4, p5, nil];
//    NSArray *arr1 = @[@"a", @"b", @"c"];
//    [arr1 writeToFile:@"/Users/hezi/Desktop/b.plist" atomically: NO];
    NSArray *arr1 = [NSArray arrayWithContentsOfFile: @"/Users/hezi/Desktop/b.plist"];

    
//    NSArray *arr2 = @[@"jack", @"r", @"a", @"d"];
//    NSString *s1 = @"asoajido,asodji,aijdo,wodw";
//
////    NSString *s1 = [arr2 componentsJoinedByString: @"!"];
//    NSArray *arr3 = [s1 componentsSeparatedByString: @","];
//    NSLog(@"%@", s1);
//    NSLog(@"%@", arr3);
    
//    for (int i = 0; i < arr1.count; i++) {
//        NSLog(@"%@", arr1[i]);
//    }
//
//    for (Person *p in arr1) {
//        NSLog(@"%@", p);
//    }
    
//    [arr1 enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//        NSLog(@"%@", obj);
//        NSLog(@"%lu", idx);
//        //如果想停止遍历，就将stop指针指向的BOOL变量的值改成YES
//        *stop = YES;
//    }];
    
//    NSLog(@"%lu", [arr1 indexOfObject: [Person new]]);
    NSLog(@"%@", arr1[0]);
//    NSLog(@"%@", arr1.firstObject);
//    NSLog(@"%@", arr1.lastObject);
//    NSLog(@"%hhd", [arr1 containsObject: p2]);
//    NSLog(@"%lu", arr1.count);
//    NSLog(@"%@", [arr2 objectAtIndex: 2]);
    return 0;
}
