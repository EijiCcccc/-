//
//  CZArray.h
//  blockDemo
//
//  Created by hezi on 2021/11/4.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef BOOL (^NewType)(char *country1, char *country2);

NS_ASSUME_NONNULL_BEGIN

@interface CZArray : NSObject

-(void)sortWithCountries: (char *)countries andLength: (int)len andCompareBlock: (NewType )compareBlock;

@end

NS_ASSUME_NONNULL_END
