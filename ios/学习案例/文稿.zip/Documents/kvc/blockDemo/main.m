//
//  main.m
//  blockDemo
//
//  Created by hezi on 2021/11/4.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CZArray.h"

int main(int argc, const char * argv[]) {
//    @autoreleasepool {
//        // insert code here...
//        NSLog(@"Hello, World!");
//    }
    char *countries[] = {
        "baadfasa",
        "aasd",
        "eadasda",
        "ca",
        "d"
    };
    CZArray *arr = [CZArray new];
    [arr sortWithCountries: countries andLength: sizeof(countries) / 8 andCompareBlock: ^BOOL(char *country1, char *country2) {
        
//按字母长度
//        int res = (int)strlen(country1) - (int)strlen(country2);
//        if (res > 0) {
//            return  YES;
//        }
//        return NO;
//按字母顺序
        int res = strcmp(country1, country2);
        return res > 0;
    }];
    
    for (int i = 0; i < sizeof(countries) / 8; i++) {
        NSLog(@"%s", countries[i]);
    }
    
    return 0;
}
