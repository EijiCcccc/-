//
//  CZArray.m
//  blockDemo
//
//  Created by hezi on 2021/11/4.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "CZArray.h"

@implementation CZArray

-(void)sortWithCountries:(char * _Nonnull *)countries andLength:(int)len andCompareBlock:(nonnull NewType)compareBlock{
    for (int i = 0; i < len - 1; i ++) {
        for (int j = 0; j < len - 1 - i; j++) {
            //比较j 和 j+1这2个字符串，直接比较的是字母顺序
            //需要执行调用代码者写的一段代码来比较大小
            BOOL res = compareBlock(countries[j], countries[j+1]);
            if (res == YES) {
                char *temp = countries[j];
                countries[j] = countries[j+1];
                countries[j+1] = temp;
            }
        }
    }
}

@end
