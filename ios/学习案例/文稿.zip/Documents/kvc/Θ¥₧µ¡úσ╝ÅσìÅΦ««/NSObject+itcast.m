//
//  NSObject+itcast.m
//  非正式协议
//
//  Created by hezi on 2021/11/3.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "NSObject+itcast.h"

@implementation NSObject (itcast)

-(void)run {
    NSLog(@"%@", self);
}

@end
