//
//  NSObject+itcast.h
//  非正式协议
//
//  Created by hezi on 2021/11/3.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSObject (itcast)

-(void)run;

@end

NS_ASSUME_NONNULL_END
