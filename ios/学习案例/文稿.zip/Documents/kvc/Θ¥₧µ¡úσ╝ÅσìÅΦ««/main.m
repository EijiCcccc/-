//
//  main.m
//  非正式协议
//
//  Created by hezi on 2021/11/3.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSObject+itcast.h"
#import "NSString+findNumber.h"

int main(int argc, const char * argv[]) {
//    @autoreleasepool {
//        // insert code here...
//        NSLog(@"Hello, World!");
//    }
    NSString *str = @"asdhajkn1k2eoqw80dijo12";
    [str findNumbre];
    
    NSObject *obj = @"asdasd1231";
    [obj run];
    
    return 0;
}
