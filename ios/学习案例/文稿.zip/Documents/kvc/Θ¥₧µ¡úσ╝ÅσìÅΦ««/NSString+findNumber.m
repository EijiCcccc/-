//
//  NSString+findNumber.m
//  非正式协议
//
//  Created by hezi on 2021/11/3.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "NSString+findNumber.h"

@implementation NSString (findNumber)

- (void)findNumbre {
    int count = 0;
    for (int i = 0; i < self.length; i++) {
        unichar ch = [self characterAtIndex: i];
        if (ch >= '0' && ch <= '9') {
        count ++;
        }
    }
    NSLog(@"%d", count);
}

@end
