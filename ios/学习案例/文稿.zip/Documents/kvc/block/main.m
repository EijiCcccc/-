//
//  main.m
//  block
//
//  Created by hezi on 2021/11/4.
//  Copyright © 2021 hezi. All rights reserved.
//

/*
1.oc在C的基础之上新增了一些数据类型
    BOOL Boolean class nil SEL id block
2. block是一个数据类型
    int(正负22亿之间) double(有效位数不超过16位小数) float(有效位数不超过7位小数) char(单个字符)..
    既然是1个数据类型，那么可以声明这个数据类的变量。可以声明block变量
    1) block是一个数据类型，可以声明一个block类型变量
    2）block类型的变量中专门存储一段代码，可以带参数和返回值。
3.block声明
    一旦声明后不可更改返回值和参数
    1)虽然block变量中使用来储存一段代码，但是1个block并不是任意的一段代码都可以存进去，而是有限定的
        在声明block变量的时候，必须要指定这个block变量是否有参数 和 返回值
        一旦指定后，这个block变量只能存储这样的代码了。
    
        声明1个block变量，返回值是void  参数是一个int类型的
        这个时候，这个block变量中就只能储存无返回值 并且有1个int参数的代码段
    2）block语法格式
        返回值类型 （^block 变量的名称)();
        void (^myBlock1)(); 声明一个block类型的变量叫做myBlock1,这个变量中只能储存没有返回值没有参数的代码段。
 4.初始化block变量
    1）原理：写一个符号block要求的代码段，储存到block变量中
    2）格式：
        ^返回值类型（参数列表）{ 代码段 }
        ^void() {};
 5.如何执行block中的代码段
    block();
 6.block 简写
    1）没有返回值，那么代码段的void可以省略
    void (^myBlock1)() = ^(){};
    2）没有参数，那么代码段的()可以省略
    void (^myBlock1)() = ^{};
    int (^myBlock2)() = ^int{};
    3）声明时有参数，可以省略声明block的变量值，代码段不省略
    4）无论代码段是否有返回值，在写代码的时候，可以不写返回值类型
 7 简化block变量的复杂定义
    1）问题： 定义block变量的时候，类型很长
    2）typedef 的使用类型：将一个长类型定义为1个短类型
    3)使用typedef将长的block类型，定义为一个短类型
    typedef 返回值类型（^新类型）(参数列表)
    typedef void (^NewType)();
    typedef int (^NewType1)(int num1, int num2);
 8.关于block块访问外部变量的问题
    1)在block代码块的内部可以取定义在外部的变量的值，定义在外部的局部变量和全局变量
    2）在block代码块的内部可以修改全局变量的值，但不能修改定义在外部的局部变量的值
    3)如果要使用外部的局部变量，在声明变量的时候加上__block
 */

#import <Foundation/Foundation.h>

int num1 = 100;

int main(int argc, const char * argv[]) {
    typedef void (^NewType)();
    
    __block int num2 = 200;
    NewType block1 = ^void() {
        int num3 = 300;
        num2 ++;
        NSLog(@"lalalalalala");
        NSLog(@"lalalalalala ===== %d", num2);
    };
    block1();
//    typedef int (^NewType1)(int num1, int num2);
//    NewType1 block2 = ^int(int num1, int num2) {
//        return num1 + num2;
//    };
//    int a = block2(1,4);
//    NSLog(@"%d", a);
    
//    typedef unsigned long long int itcast;
    
//    @autoreleasepool {
//        // insert code here...
//        NSLog(@"Hello, World!");
//    }
//    void (^myBlock1)(void) = ^void(){
//        NSLog(@"block");
//    };
//    myBlock1();
//
//    int (^myBlock2)(void) = ^int(){
//        int num1 = 10 + 20;
//        return num1;
//    };
//    int a = myBlock2();
//    NSLog(@"%d", a);
//
//    int (^myBlock3)(int, int) = ^int(int num1, int num2) {
//        return num1 + num2;
//    };
//    int b = myBlock3(11, 20);
//    NSLog(@"%d", b);
    
//    void (^myBlock1)();
//    void (^myBlock2)();
    
    
//    int num = 220000000;
//    NSLog(@"aa, %d", num);
    return 0;
}
