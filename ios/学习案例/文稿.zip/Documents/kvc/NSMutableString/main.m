//
//  main.m
//  NSMutableString
//
//  Created by hezi on 2021/11/5.
//  Copyright © 2021 hezi. All rights reserved.
//

/*
 1.NSString字符串的恒定性
 NSLog(@"---------");
 NSString *str = @"";
 for (int i = 0; i < 50000; i ++) {
     str = [NSString stringWithFormat:@"%@, %d", str, i];
 }
 NSLog(@"---------");
 会耗费很长时间，每次循环的时候，都会新建一个对象
 
 2.NSMutableString
    1)是foundation框架中的一个类，从NSString继承
        是用来存储字符串数据的
    2）NSMutableString在 父类NSString的基础上做的扩展
        存储在NSMutableString对象中的字符串可以修改，不会新建对象
 
 3.NSMutableString的使用
 创建对象
 + (instancetype)stringWithString:(NSString *)string;
 追加字符串
 - (void)appendString:(NSString *)aString;
 拼接追加字符串
 - (void)appendFormat:(NSString *)format, ... NS_FORMAT_FUNCTION(1,2);
 不能通过赋值@"xxx"
 @"jack"是一个NSString对象，是一个父类对象，而str是一个NSMuatbleString类型，是一个子类
 在调用子类中的方法时 会允许报错。
 
 4.在使用NSString的时候， 完全可以使用NSMutableString
 
 5.使用NSMutableString来做大批量字符串拼接
    NSLog(@"---------");
    NSMutableString *str = [NSMutableString string];
    for (int i = 0; i < 500000; i ++) {
        [str appendFormat:@"%d", i];
    }
    NSLog(@"---------");
 
 6.
    平时使用NSString， 效率高
    大量拼接时使用NSMutableString （建议10次以上）
 */


#import <Foundation/Foundation.h>
#import "Person.h"

int main(int argc, const char * argv[]) {
//    @autoreleasepool {
//        // insert code here...
//        NSLog(@"Hello, World!");
//    }
//    NSMutableString *str = [NSMutableString string];
//    [str appendString: @"jack "];
//    [str appendString: @"rose "];
//    [str appendFormat: @"name%d", 10];
    
//    NSMutableString *str = @"jack";
//    Person *p1 = [Person new];
//    NSString *s1 = @"asdads";
//    NSMutableString *s2 = [NSMutableString string];
//    [s2 appendString:@"adasd"];
//    [p1 eat: s2];
//    [p1 eat: s1];
    
//    NSLog(@"%@", str);
    
    NSLog(@"---------");
    NSMutableString *str = [NSMutableString string];
    for (int i = 0; i < 500000; i ++) {
        [str appendFormat:@"%d", i];
    }
    NSLog(@"---------");
    return 0;
}
