//
//  Student.h
//  category
//
//  Created by hezi on 2021/11/3.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Student : NSObject {
    NSString *_name;
}

@property (nonatomic, assign) int age;

- (void)haha;

@end

NS_ASSUME_NONNULL_END
