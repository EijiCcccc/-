//
//  Student+itcast.h
//  category
//
//  Created by hezi on 2021/11/4.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "Student.h"

NS_ASSUME_NONNULL_BEGIN

@interface Student ()

@property (nonatomic, copy) NSString *str1;

- (void)sleep;

@end

NS_ASSUME_NONNULL_END
