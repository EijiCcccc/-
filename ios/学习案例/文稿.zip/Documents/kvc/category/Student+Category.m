//
//  Student+Category.m
//  category
//
//  Created by hezi on 2021/11/3.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "Student+Category.h"

@implementation Student (Category)

- (NSString *)name {
    return _name;
}

- (void)setName:(NSString *)name {
    self.age = 10;
    _name = name;
}

- (void)hehe {
    NSLog(@"heheheheheh");
}

@end
