//
//  Student.m
//  category
//
//  Created by hezi on 2021/11/3.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "Student.h"
#import "Student+itcast.h"

@interface Student ()

@end

@implementation Student

-(void)haha {
    NSLog(@"hahahahahahahahahaha");
}

-(void)sleep {
    NSLog(@"sleep");
}

@end
