//
//  main.m
//  category
//
//  Created by hezi on 2021/11/3.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Student.h"
#import "Student+Category.h"
#import "Student+itcast.h"

int main(int argc, const char * argv[]) {
//    @autoreleasepool {
//        // insert code here...
//        NSLog(@"Hello, World!");
//    }
    Student *s1 = [Student new];
    [s1 sleep];
    s1.name = @"a";
    s1.str1 = @"b";
    s1.age = 10;
    return 0;
}
