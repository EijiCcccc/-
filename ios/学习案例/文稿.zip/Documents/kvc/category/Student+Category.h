//
//  Student+Category.h
//  category
//
//  Created by hezi on 2021/11/3.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "Student.h"

NS_ASSUME_NONNULL_BEGIN

@interface Student (Category)

@property (nonatomic, strong) NSString *name;

- (void) hehe;

@end

NS_ASSUME_NONNULL_END
