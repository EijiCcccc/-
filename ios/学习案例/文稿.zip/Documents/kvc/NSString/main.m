//
//  main.m
//  foundation
//
//  Created by hezi on 2021/11/4.
//  Copyright © 2021 hezi. All rights reserved.
//
/*
 
 框架中有很多功能相似的类，函数库
 Foundation框架：定义了一些基础的类,其他的框架都是基于Foundation
 
 UIKit，AVFoundation...
 
 3.NSSting
    1）NSString 是一个数据类型，保存oc字符串
    NSString *str1 = [NSString new];
    NSString *str2 = [NSString string];
    NSString *str3 = [[NSString alloc] init];
    创建空字符串
    2）NSString *str = @"rose";
        1)@"rose"本质上是一个NSString对象，这个对象中存储的字符串是“rose”
        2)将这个字符串对象的地址返回赋值给str指针
    格式控制符 %p: 打印指针变量的值，打印地址
             %@：打印指针指向的对象
 4.NSString 恒定性
    NSString *str = @"jack";
    @"jack"存储在数据段（常量区)
    NSString *str1 = [NSString stringWithFormar:@"jack"];
    创建的字符串对象在堆区
    
    当在内存总创建一个字符串对象后，这个字符串对象的内容就无法改变
    当我们重新为字符串指针初始化值的时候，并不是修改原来的字符串对象
    而是重新创建一个字符串对象，将这个字符串对象的地址重新赋值给指针变量
 
    当系统准备要在内容中创建字符串的时候，会先检查内存中是否有相同内容的字符串对象
    如果有，直接指向，如果没有才会重新创建
 
    存储在常量区的字符串不会被回收
 
    字符串不能通过==去判断，因为==比较的是字符串指针变量的值，而我们要比的是2个字符串指针指向对象的内容是否相同

 1.将字符串内存写入到磁盘的某一个文件之中
 - (BOOL)writeToFile:(NSString *)path atomically:(BOOL)useAuxiliaryFile encoding:(NSStringEncoding)enc error:(NSError **)error;
    参数1:将字符串内容写入到哪一个文件中，写上文件的路径
    参数2:YES, 先将参数写入到一个临时文件。如果成功再将这个文件搬到指定目录
        安全，效率低
            NO,直接将内容写到指定文件，不安全，效率高
    参数3:使用UTF-8编码  NSUTF8StringEncoding
    参数4: 二级指针，传递一个NSError指针的地址
            如果成功，这个指针为nil
            如果失败，这个指针指向一个错误对象，这个对象描述了发生的错误
            对象的localizedDescription 可以得到错误的简要说明
    返回BOOL类型，代表是否写入成功

2.从磁盘中读取文件的内容
 
3.使用URL来读写字符串数据
    1）优势： 读写本地磁盘文件，读写网页文件  ftp服务器的文件
    2) 不同的类型URL地址写法
        1）本地磁盘文件： file:///Users/hezi/Desktop/a.txt
        2) 网页： http://www.itcast.cn/index.html
        3) ftp文件的地址： ftp://server.itcast.cn/1.txt
    3) 将地址写入NSURL对象
 
 4.字符串比较
 - (NSComparisonResult)compare:(NSString *)string;
    options: 选取忽略大小写，相同格式数字的判断
 
 字符串是否以指定字符串开头
 - (BOOL)hasPrefix:(NSString *)str;
 字符串是否以指定字符串结尾
 - (BOOL)hasSuffix:(NSString *)str;
 字符串中搜索子字符串
 - (NSRange)rangeOfString:(NSString *)searchString;
 返回值 NSRange结构体
 typedef struct _NSRange {
     NSUInteger location;  代表字串在主串出现的下表
     NSUInteger length;  代表字串在主串中匹配的长度
 } NSRange;
 
 NSRange 结构体赋值
 1.NSRange range;
    range.location = 3;
    range.length = 1;
 2.NSRange range = {3, 7};
    NSRange range = {.location: 3, .length: 7};
 
 从字符串中截取
 - (NSString *)substringFromIndex:(NSUInteger)from;
 从指定下标一直截取到最后
 - (NSString *)substringToIndex:(NSUInteger)to;
 从0一直截取到指定的个数
 - (NSString *)substringWithRange:(NSRange)range;
 按照NSRange的范围截取
 
 
 字符串的替换
 将字符串中第一个参数替换为第二个参数，全部替换
 原来指针字符串的内容不会改变
 新字符串是以方法的返回值返回
 - (NSString *)stringByReplacingOccurrencesOfString:(NSString *)target withString:(NSString *)replacement
 
 
 字符串转化为其他类型
 @property (readonly) double doubleValue;
 @property (readonly) float floatValue;
 @property (readonly) int intValue;
 @property (readonly) NSInteger integerValue API_AVAILABLE(macos(10.5), ios(2.0), watchos(2.0), tvos(9.0));
 @property (readonly) long long longLongValue API_AVAILABLE(macos(10.5), ios(2.0), watchos(2.0), tvos(9.0));
 @property (readonly) BOOL boolValue API_AVAILABLE(macos(10.5), ios(2.0),
 
 去掉字符串前后的空格
 - (NSString *)stringByTrimmingCharactersInSet:(NSCharacterSet *)set;
 中间无法去掉
 
 转化为大写
 @property (readonly, copy) NSString *uppercaseString;
 转化为小写
 @property (readonly, copy) NSString *lowercaseString;
 
 */
#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    
    NSString *str = @"audihqjnwkailh";
    str = [str uppercaseString];
//    NSString *str = @"    12312313    ";
//    str = [str stringByTrimmingCharactersInSet: [NSCharacterSet whitespaceCharacterSet]];
    
//    NSString *str = @"121.12";
//    double num = str.doubleValue;
//    NSLog(@"%f", num + 1);
    
//    NSString *str = @"asd\n123ada\n12a112a\n";
//    NSLog(@"%@", str);
//    str = [str stringByReplacingOccurrencesOfString: @"\n" withString: @""];
//    NSLog(@"%@", str);
    
    
//    NSString *str = @"http://www.baidu.www.com";
//    NSString *str1 = [str stringByReplacingOccurrencesOfString: @"www" withString: @"aaa"];
//    NSLog(@"%@", str1);
    
//    NSRange range = NSMakeRange(1, 2);
//    NSRange range = {3, 7};
//    NSRange range1 = {.location = 3, .length = 7};
//    打印NSRange
//    NSLog(@"%lu %lu", range.location, range.length);
//    NSLog(@"%@", NSStringFromRange(range));
    
//    NSString *str = @"http://www.baidu.www.com";
////    BOOL res = [str hasSuffix: @".com"];
////    BOOL res = [str hasPrefix:@"http"];
//    NSRange range = [str rangeOfString:@"www"];
//    //从前往后
//    NSRange range1 = [str rangeOfString:@"www" options: NSBackwardsSearch];
//    //从后往前
//    NSLog(@"loc = %lu", range1.location);
//    NSLog(@"loc = %lu", range1.length);
//    if (range.length > 0 || range.location == NSNotFound) {
//
//    }
    
//    NSString *str1 = @"pic10010.jpg";
//    NSString *str2 = @"pic10010.jpg";
//    //只能比较格式固定的str
//    NSComparisonResult res = [str1 compare: str2 options: NSNumericSearch];
//
    
//    NSString *str1 = @"jack";
//    NSString *str2 = @"JACK";
//
////    NSComparisonResult res = [str1 compare: str2];
//
//    NSComparisonResult res = [str1 compare: str2 options: NSCaseInsensitiveSearch];
//
//    switch (res) {
//        case NSOrderedAscending:
//            // str1 < str2
//            NSLog(@"小");
//            break;
//        case NSOrderedSame:
//            //str1 = str2
//            NSLog(@"一样");
//            break;
//        case NSOrderedDescending:
//            NSLog(@"大");
//            //str1 > str2
//            break;
//        default:
//            break;
//    }
    
    
    
    
//    NSURL *u1 = [NSURL URLWithString: @"file:///Users/hezi/Desktop/a.txt"];
//    NSString *str = [NSString stringWithContentsOfURL: u1 encoding: NSUTF8StringEncoding error:nil];
//    NSString *str1 =  @"hehhehheheheheh";
//    [str1 writeToURL: u1 atomically: NO encoding:NSUTF8StringEncoding error:nil];
//    NSLog(@"%@", str1);
//    NSLog(@"%@", str);
    
//    NSString *str = [NSString stringWithContentsOfFile: @"/Users/hezi/Desktop/a.txt" encoding: NSUTF8StringEncoding error: nil];
//    NSLog(@"%@", str);
    
//    NSString *a  = @"萨大战小夫妻第九期哦没看到我";
//    NSError *err;
//    BOOL res = [a writeToFile:@"/Users/hezi/Desktop/a.txt" atomically: NO encoding: NSUTF8StringEncoding error: &err];
//    if (err) {
//        //写入失败
//        NSLog(@"%@", err.localizedDescription);
//    } else {
//        //写入失败
//    }
    
    //将C字符串转化为OC字符串
//    char *str = "jack";
//    NSString *s = [NSString stringWithUTF8String: str];
//    NSLog(@"%@", s);
//
//    NSString *str1 = @"jack";
//    NSString *str2 = [NSString stringWithFormat:@"jack"];
//    BOOL res = [str1 isEqualToString: str2];
//    NSLog(@"bool == %hhd",res);
//
//    int age = 10;
//    NSString *str = @"jack";
//    NSString *str1 = [NSString stringWithFormat:@"%d%@",age,str];
//
//    NSUInteger len = str.length;
//    NSString *str1 = [NSString new];
//    NSLog(@"\nstr1 = %p", &str1);
//    str1 = nil;
//    NSLog(@"\nstr1 = %p", str1);
//    NSString *str2 = [NSString new];
//    NSLog(@"\nstr1 = %p", str2);
    
//    NSString *str1 = [NSString new];
//    NSString *str1 = @"jack";
//    NSLog(@"\nstr1 = %p", str1);
//    str1 = @"jack1";
//    NSString *str2 = @"jack";
////    NSString *str2 = [NSString new];
//    NSLog(@"\nstr1 = %p", str2);
    
//    NSString *str1 = @"jack";
//    NSString *str3 = @"jack1";
//    NSString *str2 = [NSString new];
//
//    NSLog(@"\nstr1 = %p\nstr2 = %p\nstr3 = %p", str1, str2, str3);
    
    return 0;
}
