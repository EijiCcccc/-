//
//  main.m
//  单例
//
//  Created by hezi on 2021/11/8.
//  Copyright © 2021 hezi. All rights reserved.
//

/*
 1.单例模式
    1个类的对象，无论在何时何地创建，也无论创建多少次，创建出来的都是用一个对象
 2.无论如何创建对象，最终都是调用alloc来创建对象
    1）allocWithZone重写
     + (instancetype)allocWithZone:(struct _NSZone *)zone {
         static id instance = nil;
         if (instance == nil) {
             instance = [super allocWithZone: zone];
         }
         return instance;
     }
    2) 如果类是一个单例模式，要求为类提供一个类方法，来返回这个单例对象
        类方法的名称 必须是以 shared类名； default类名
3. 什么时候要把类变成单例
    1）单例对象的数据可以共享，在任何地方访问的都是同一个对象
    2）如果数据需要被整个程序共享，可以在任何地方修改，并影响全局

 */

#import <Foundation/Foundation.h>
#import "Person.h"

int main(int argc, const char * argv[]) {
//    @autoreleasepool {
//        // insert code here...
//        NSLog(@"Hello, World!");
//    }
    Person *p1 = [Person sharedPerson];
    Person *p2 = [Person sharedPerson];
    Person *p3 = [Person sharedPerson];
    Person *p4 = [Person sharedPerson];
    return 0;
}
