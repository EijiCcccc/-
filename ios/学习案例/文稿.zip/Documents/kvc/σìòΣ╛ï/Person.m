//
//  Person.m
//  单例
//
//  Created by hezi on 2021/11/8.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "Person.h"

@implementation Person

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    static id instance = nil;
    if (instance == nil) {
        instance = [super allocWithZone: zone];
    }
    return instance;
}

+(instancetype)sharedPerson {
    return [self new];
}

+ (instancetype)defaultPerson {
    return [self new];
}
@end
