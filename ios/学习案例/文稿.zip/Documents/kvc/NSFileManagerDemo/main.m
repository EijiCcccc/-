//
//  main.m
//  NSFileManagerDemo
//
//  Created by hezi on 2021/11/8.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *path = @"/Users/hezi/Desktop/文件终结者/";
    NSArray *arr = [fileManager contentsOfDirectoryAtPath: path error: nil];
    if (arr.count > 0) {
        for (NSString *p in arr) {
            NSString *newPath = [NSString stringWithFormat: @"%@%@", path, p];
            if ([fileManager isDeletableFileAtPath: newPath]) {
                [fileManager removeItemAtPath: newPath error: nil];
            }
        }
        NSLog(@"扫描成功");
    }
    [NSThread sleepForTimeInterval: 3]; //cpu暂停指定的时间
    return 0;
}
