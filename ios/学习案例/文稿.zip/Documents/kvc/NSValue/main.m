//
//  main.m
//  NSValue
//
//  Created by hezi on 2021/11/8.
//  Copyright © 2021 hezi. All rights reserved.
//
/*
 1.结构体  NSRange CGPoint CGSize CGRect
 2.解决方案，将结构体变量存储到OC对象中，在吧对象存储到集合之中
 3.NSValue
 
 
 */

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
//    @autoreleasepool {
//        // insert code here...
//        NSLog(@"Hello, World!");
//    }
    
    CGSize s1 = CGSizeMake(1, 2);
    CGSize s2 = CGSizeMake(1, 2);
    CGSize s3 = CGSizeMake(1, 2);
    CGSize s4 = CGSizeMake(1, 2);
    
    NSValue *v1 = [NSValue valueWithSize: s1];
    NSValue *v2 = [NSValue valueWithSize: s2];
    NSValue *v3 = [NSValue valueWithSize: s3];
    NSValue *v4 = [NSValue valueWithSize: s4];
    
    NSArray *arr = @[v1, v2, v3, v4];
//    CGPoint p1 = CGPointMake(10, 20);
//    CGPoint p2 = CGPointMake(20, 30);
//    CGPoint p3 = CGPointMake(30, 40);
//    CGPoint p4 = CGPointMake(40, 50);
//
//    NSValue *v1 = [NSValue valueWithPoint: p1];
//    NSValue *v2 = [NSValue valueWithPoint: p2];
//    NSValue *v3 = [NSValue valueWithPoint: p3];
//    NSValue *v4 = [NSValue valueWithPoint: p4];
//
//    NSArray *arr = @[v1, v2, v3, v4];
    
    for (NSValue *v in arr) {
        NSLog(@"%@", NSStringFromSize(v.sizeValue));
    }
    
    return 0;
}
