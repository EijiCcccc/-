//
//  NSDate+itcast.h
//  NSDate
//
//  Created by hezi on 2021/11/8.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSDate (itcast)

@property (nonatomic, assign, readonly) int year;

@end

NS_ASSUME_NONNULL_END
