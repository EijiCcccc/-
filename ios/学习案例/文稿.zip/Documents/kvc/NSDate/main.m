//
//  main.m
//  NSDate
//
//  Created by hezi on 2021/11/8.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSDate+itcast.h"

int main(int argc, const char * argv[]) {
    
    NSDate *date = [NSDate date];
    NSLog(@"%d", date.year);
    
//    NSDate *date = [NSDate new];
//    NSLog(@"%@", date);
//    NSDateFormatter *formatter = [NSDateFormatter new];
//    formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
//    //格式化对象按照指定的格式将日期对象转换
//    //转换的时候会自动的转换为当前系统的时区的时间
//    NSString *str = [formatter stringFromDate: date];
//    NSLog(@"%@", str);
    
//    NSString *strData = @"2011年12月12号 12点12分12秒";
//    NSDateFormatter *formatter = [NSDateFormatter new];
//    formatter.dateFormat = @"yyyy年MM月dd号 HH点mm分ss秒";
//    NSDate *data = [formatter dateFromString: strData];
//    NSLog(@"%@", data);
    
    //5000s后的时间
//    NSDate *data = [NSDate dateWithTimeIntervalSinceNow: 5000];
//    NSLog(@"%@", data);
    
//    NSString *str = @"";
//    NSDate *startDate = [NSDate new];
//    for (int i = 0; i < 10000; i ++) {
//        str = [NSString stringWithFormat: @"%@%d", str, i];
//    }
//    NSDate *endDate = [NSDate new];
//    NSTimeInterval sj = [endDate timeIntervalSinceDate: startDate];
//    NSLog(@"%f", sj);
    
//    NSDate *date = [NSDate date];
//    NSCalendar *calendar = [NSCalendar currentCalendar];
//    NSDateComponents * com = [calendar components: NSCalendarUnitYear | NSCalendarUnitDay | NSCalendarUnitWeekday | NSCalendarUnitHour fromDate: date];
//
//    NSLog(@"%lu", com.hour);
    return 0;
}
