//
//  NSDate+itcast.m
//  NSDate
//
//  Created by hezi on 2021/11/8.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "NSDate+itcast.h"

@implementation NSDate (itcast)

-(int)year {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents * com = [calendar components: NSCalendarUnitYear | NSCalendarUnitDay | NSCalendarUnitWeekday | NSCalendarUnitHour fromDate: self];
    return (int)com.year;
}

@end
