//
//  CZNumber.m
//  NSNumber
//
//  Created by hezi on 2021/11/5.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "CZNumber.h"

@implementation CZNumber

-(instancetype)initWithIntValue:(int)number {
    if (self = [super init]) {
        self.number = number;
    }
    return self;
}

+ (instancetype)numberWithIntValue:(int)number {
    return [[self alloc] initWithIntValue: number];
}

@end
