//
//  main.m
//  NSNumber
//
//  Created by hezi on 2021/11/5.
//  Copyright © 2021 hezi. All rights reserved.
//

/*
 1.定义1个类，这个类的对象的作用是用来存储1个int类型的数据，再将这个对象存储到Array数组中
 2.NSNumber 是Foundation框架中的一个类，用来包装基本数据类型
 //    NSNumber *num1 = [NSNumber numberWithInt: 1];
 //    NSNumber *num2 = [NSNumber numberWithInt: 2];
 //    NSNumber *num3 = [NSNumber numberWithInt: 3];
 //    NSNumber *num4 = [NSNumber numberWithInt: 4];
 //    NSArray *arr = @[num1, num2, num3, num4];
 3.简写方式
 @10代表是一个NSNumber对象，这个对象中包装的是整形的10
 NSArray *arr = @[@10, @20, @30];
 
 用NSNumber将基本类型包装
 int a = 10;
 NSNumber = @(a);
 */

#import <Foundation/Foundation.h>
#import "CZNumber.h"

int main(int argc, const char * argv[]) {
    
//    NSNumber *num1 = [NSNumber numberWithInt: 1];
//    NSNumber *num2 = [NSNumber numberWithInt: 2];
//    NSNumber *num3 = [NSNumber numberWithInt: 3];
//    NSNumber *num4 = [NSNumber numberWithInt: 4];

//    NSNumber *num1 = [NSNumber numberWithFloat: 10.1f];
//    NSNumber *num2 = [NSNumber numberWithFloat: 10.2f];
//    NSNumber *num3 = [NSNumber numberWithFloat: 10.3f];
//    NSNumber *num4 = [NSNumber numberWithFloat: 10.4f];
//    NSNumber *num1 = @10;
//    NSNumber *num2 = @20;
//    NSNumber *num3 = @30;
//    NSNumber *num4 = @40;
    
//    CZNumber *num1 = [CZNumber numberWithIntValue: 10];
//    CZNumber *num2 = [CZNumber numberWithIntValue: 20];
//    CZNumber *num3 = [CZNumber numberWithIntValue: 30];
//    NSArray *arr = @[num1, num2, num3, num4];
    //@10代表是一个NSNumber对象，这个对象中包装的是整形的10
    NSArray *arr = @[@10, @20, @30];
    for (NSNumber *number in arr) {
        NSLog(@"%f", number.floatValue);
    }
    return 0;
}
