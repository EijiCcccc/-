//
//  main.m
//  blockDemo2
//
//  Created by hezi on 2021/11/4.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CZArray.h"

typedef void (^NewType)();

NewType ttt() {
    NewType block1 = ^{
        NSLog(@"aaaaaa");
    };
    return block1;
}

int main(int argc, const char * argv[]) {
//    @autoreleasepool {
//        // insert code here...
//        NSLog(@"Hello, World!");
//    }
    CZArray *arr = [[CZArray alloc] init];
    [arr bianliWithBlock:^(int val) {
        NSLog(@"%d", val);
    }];
    ttt()();
    return 0;
}
