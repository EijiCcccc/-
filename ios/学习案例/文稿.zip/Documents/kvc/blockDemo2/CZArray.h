//
//  CZArray.h
//  blockDemo2
//
//  Created by hezi on 2021/11/4.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CZArray : NSObject
{
    int _arr[10];
}

-(void)bianliWithBlock: (void (^)(int val)) block;

@end

NS_ASSUME_NONNULL_END
