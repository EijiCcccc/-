//
//  CZArray.m
//  blockDemo2
//
//  Created by hezi on 2021/11/4.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "CZArray.h"

@implementation CZArray

-(instancetype)init {
    if (self = [super init]) {
        for (int i = 1; i < 11; i ++) {
            _arr[i - 1] = i * 10;
        }
    }
    return self;
}

-(void)bianliWithBlock:(void (^)(int))block {
    for (int i = 0; i < 10; i ++) {
        block(_arr[i]);
    }
}

@end
