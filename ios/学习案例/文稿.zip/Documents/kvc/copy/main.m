//
//  main.m
//  copy
//
//  Created by hezi on 2021/11/8.
//  Copyright © 2021 hezi. All rights reserved.
//

/*
 
1.copy方法的确定义在NSObject中
    copy方法的内部调用了另外一个方法， copyWithZone;
    这个方法是定义在NSCoping协议之中
    所有当我们没有遵守NSCoping协议，那么我们类中就没有copyWithZone这个方法
    
 
    如果想让自定义类有copy方法，需要遵守NSCoping协议，并实现copytWithZone方法
        如果要实现深拷贝： 新建对象并赋值，返回这个对象
        如果要实现浅拷贝： return self
 
2.copy 复制
    copy是一个方法，定义在NSObject中，作用：拷贝对象
    NSString -> copy -> 没有产生新的对象，而是直接将对象本身的地址返回，这种拷贝叫做浅拷贝
    NSMutableString -> copy  有产生一个新的对象NSString, 是一个不可改变的字符串对象，这种拷贝叫做深拷贝
 
    mutableCopy
    NSString - > mutableCopy - > 可变字符串对象 深拷贝
    NSMutableString -> mutableCopy -> 可变字符串对象 深拷贝
 
3.字符串对象拷贝的引用计数器
    1)若字符串对象在常量区中， 存储在常量区的数据是不允许被回收的
    2) 若字符串在堆区，这个字符串对象和普通对象是一样的, 引用计数器默认值为1
    3) 字符串如果是浅拷贝， retainCount + 1
       字符串如果是浅拷贝， 原来的对象retaincount不变
 */

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
//    @autoreleasepool {
//        // insert code here...
//        NSLog(@"Hello, World!");
//    }
//    NSString *str1 = @"jack";
//    NSString *str2 = [str1 copy];
    
//    NSString *str = [NSString stringWithFormat: @"jack"];
//    NSLog(@"%lu", str.retainCount);
//    NSMutableString *str1 = [NSMutableString stringWithString: @"jack"];
//    NSMutableString *str2 = [str1 mutableCopy];
    
    
    NSString *s1 = [NSString stringWithFormat:@"adasd%@", @"a"];
//    NSString *s2 = [s1 copy];
    NSLog(@"s1 %lu", s1.retainCount);
//
//    [str2 appendString: @"jjj"];
//
//    NSLog(@"str1 = %@", str1);
//    NSLog(@"str2 = %@", str2);
//
//    NSLog(@"str1 = %p", str1);
//    NSLog(@"str2 = %p", str2);
    return 0;
}
