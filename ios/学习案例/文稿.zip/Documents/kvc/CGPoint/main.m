//
//  main.m
//  CGPoint
//
//  Created by hezi on 2021/11/8.
//  Copyright © 2021 hezi. All rights reserved.
//

/*
 1.CGPoint 保存位置
 在foundation框架中，定义了一个结构体CGPoint
 typedef CGPoint {
    CGFloat x;
    CGFloat y;
 }
 typedef struct CGPoint CGPoint;
 
 创建初始化
CGPoint p1;
 p1.x = 20;
 p1.y = 30;
 
 CGPoint p1 = {20, 30};
 
 CGPoint p1 = {.x = 20, .y = 30};
 
 CGPoint p1 = CGPointMake(20, 30);
 
 2.CGSize 保存大小
 typedef CGSize {
    double width;
    double height;
 };
 stypdef struct CGSize CGSize;
 

 CGSize p1;
  p1.x = 20;
  p1.y = 30;
  
  CGSize p1 = {20, 30};
  
  CGSize p1 = {.x = 20, .y = 30};
  
  CGSize p1 = CGSizeMake(20, 30);
 
 3.CGRect
 struct CGRect {
    CGPoint origin;
    CGSize size;
 }
 rect.origin = (CGPoint) {10, 20};
 rect.size = (CGSize) {10, 20};
 
 */

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
//    CGPoint p1 = CGPointMake(20, 30);
//    
//    CGRect rect;
//    rect.origin = (CGPoint) {10, 20};
//    rect.size = (CGSize) {10, 20};
    return 0;
}
