//
//  CZButton.h
//  CGPoint
//
//  Created by hezi on 2021/11/8.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CZButton : NSObject

@property (nonatomic, assign) CGPoint point;

@property (nonatomic, assign) CGSize size;

@property (nonatomic, strong) NSString *str;

@end

NS_ASSUME_NONNULL_END
