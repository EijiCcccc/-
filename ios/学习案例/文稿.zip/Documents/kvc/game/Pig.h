//
//  Pig.h
//  game
//
//  Created by hezi on 2021/11/2.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "Animal.h"

NS_ASSUME_NONNULL_BEGIN

@interface Pig : Animal

-(void)eat;
@end

NS_ASSUME_NONNULL_END
