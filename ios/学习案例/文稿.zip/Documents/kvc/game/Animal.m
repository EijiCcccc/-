//
//  Person.m
//  game
//
//  Created by hezi on 2021/11/2.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "Animal.h"

@implementation Animal


-(void)run {
    NSLog(@"run");
}

- (instancetype)initWith:(NSString *)pigName andAnimalName:(NSString *)name {
    NSLog(@"aaaaa");
    if (self = [super init]) {
        self.name = name;
    }
    return self;
}

@end
