//
//  main.m
//  game
//
//  Created by hezi on 2021/11/2.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Animal.h"
#import "Pig.h"

int main(int argc, const char * argv[]) {
//    Pig *p1 = [Animal new];
//    [p1 eat];
//    [p1 run];
    NSObject *obj = [Animal new];
    id id1 = [Animal new];
    
    [(Animal *)obj run];
    [id1 run];
    
    Animal *a = [[Animal alloc] initWith:@"a" andAnimalName:@"b"];
    
    
    return 0;
}
