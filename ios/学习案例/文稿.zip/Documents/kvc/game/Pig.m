//
//  Pig.m
//  game
//
//  Created by hezi on 2021/11/2.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "Pig.h"

@implementation Pig

-(void)eat {
    
}

@end
