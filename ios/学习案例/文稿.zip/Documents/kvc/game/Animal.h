//
//  Person.h
//  game
//
//  Created by hezi on 2021/11/2.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Animal : NSObject

@property (nonatomic, copy) NSString *name;

-(void)run;

-(instancetype)initWith: (NSString *)pigName andAnimalName: (NSString *)name;

@end

NS_ASSUME_NONNULL_END
