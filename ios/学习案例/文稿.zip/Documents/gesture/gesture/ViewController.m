//
//  ViewController.m
//  gesture
//
//  Created by hezi on 2021/11/12.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <UIGestureRecognizerDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *image;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //创建手势对象
    //对一个view添加手势
    //实现手势的方法
    
    //UITabGestureRecognizer(敲击)
//    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget: self action: @selector(tap:)];
//    
//    tap.numberOfTapsRequired = 2;
//    tap.numberOfTouchesRequired = 2;
//    [self.image addGestureRecognizer: tap];
    
//    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget: self action: @selector(longPress:)];
//
//    longPress.minimumPressDuration = 3;
//    longPress.allowableMovement = 10;
//
//    [self.image addGestureRecognizer: longPress];
    
//    UISwipeGestureRecognizer *swipe = [[UISwipeGestureRecognizer alloc] initWithTarget: self action: @selector(swipe:)];
//
//    swipe.direction = UISwipeGestureRecognizerDirectionLeft;
//    [self.image addGestureRecognizer: swipe];
    
    UIRotationGestureRecognizer *rotation = [[UIRotationGestureRecognizer alloc]initWithTarget:self action: @selector(rotation:)];
    rotation.delegate = self;
    [self.image addGestureRecognizer: rotation];
    
    UIPinchGestureRecognizer *pinch = [[UIPinchGestureRecognizer alloc] initWithTarget: self action: @selector(pinch:)];
//    pinch.delegate = self;
    [self.image addGestureRecognizer: pinch];
    
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget: self action:@selector(pan:)];
    pan.delegate = self;
    [self.image addGestureRecognizer: pan];
    
}

-(void)pan: (UIPanGestureRecognizer *) sender {
    CGPoint p = [sender translationInView: sender.view];
    
    self.image.transform = CGAffineTransformTranslate(self.image.transform, p.x, p.y);
    
    [sender setTranslation: CGPointZero inView: sender.view];
}

-(void)pinch: (UIPinchGestureRecognizer *)sender {
    NSLog(@"%f", sender.scale);
    self.image.transform = CGAffineTransformScale(self.image.transform, sender.scale, sender.scale);
    
    sender.scale = 1;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return YES;
}

-(void)rotation: (UIRotationGestureRecognizer *)sender {
    NSLog(@"%f", sender.rotation);
    
//    self.image.transform = CGAffineTransformMakeRotation(sender.rotation);
    
    self.image.transform = CGAffineTransformRotate(self.image.transform, sender.rotation);
    //需要恢复到初始的状态
    sender.rotation = 0;
}


-(void)swipe: (UISwipeGestureRecognizer *)sender {
    
}

-(void)tap: (UITapGestureRecognizer *)sender {
    NSLog(@"%@", sender);
}

-(void)longPress: (UILongPressGestureRecognizer *)sender {
    if (sender.state == UIGestureRecognizerStateBegan) {
        
    }
}

@end
