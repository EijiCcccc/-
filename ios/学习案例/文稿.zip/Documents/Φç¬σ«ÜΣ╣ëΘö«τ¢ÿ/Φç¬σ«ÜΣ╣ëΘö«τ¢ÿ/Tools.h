//
//  Tools.h
//  自定义键盘
//
//  Created by hezi on 2021/11/8.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Tools : NSObject

+(int)sum: (int)a andB: (int)b;

@end

NS_ASSUME_NONNULL_END
