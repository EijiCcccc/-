//
//  ViewController.m
//  自定义键盘
//
//  Created by hezi on 2021/10/28.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *textField;

@property (nonatomic, strong) UIDatePicker *dataPicker;
@property (nonatomic, strong) UIToolbar *toolBar;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.textField.inputView = self.dataPicker;
    self.textField.inputAccessoryView = self.toolBar;
    // Do any additional setup after loading the view.
}

#pragma mark - 懒加载
-(UIDatePicker *)dataPicker {
    if (!_dataPicker) {
        _dataPicker = [[UIDatePicker alloc] init];
        _dataPicker.datePickerMode = UIDatePickerModeDate;
        _dataPicker.locale = [[NSLocale alloc] initWithLocaleIdentifier: @"zh-Hans"];
    }
    return _dataPicker;
}

-(UIToolbar *)toolBar {
    if (!_toolBar) {
        _toolBar = [[UIToolbar alloc] init];
        _toolBar.bounds = CGRectMake(0, 0, 0, 44);
        //创建按钮
        UIBarButtonItem *cancelItem = [[UIBarButtonItem alloc] initWithTitle: @"取消" style: UIBarButtonItemStylePlain target: self action:@selector(cancelItemClick)];
        
        UIBarButtonItem *flexSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemFlexibleSpace target: self action: nil];
        
        UIBarButtonItem *doneItem = [[UIBarButtonItem alloc] initWithTitle: @"确认" style: UIBarButtonItemStylePlain target: self action:@selector(doneItemClick)];
        
        _toolBar.items = @[cancelItem, flexSpace, doneItem];
    }
    return _toolBar;
}

-(void)cancelItemClick {
    [self.view endEditing: YES];
}

-(void)doneItemClick {
//    int a = [Tools sum: 12 andB: 13];
//    NSLog(@"%d", a);
    NSDate *data = self.dataPicker.date;
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy:MM:dd HH:mm:ss";
    _textField.text = [formatter stringFromDate: data];
    
    
    [self.view endEditing: YES];
}

@end
