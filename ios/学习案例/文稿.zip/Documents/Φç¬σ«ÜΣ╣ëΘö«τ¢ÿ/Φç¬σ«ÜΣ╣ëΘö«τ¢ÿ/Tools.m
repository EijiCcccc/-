//
//  Tools.m
//  自定义键盘
//
//  Created by hezi on 2021/11/8.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "Tools.h"

@implementation Tools

+(int)sum:(int)a andB:(int)b {
    return  a + b;
}

@end
