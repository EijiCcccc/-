//
//  HMProvince.m
//  城市选择
//
//  Created by hezi on 2021/10/28.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "HMProvince.h"

@implementation HMProvince

-(instancetype)initWithDic:(NSDictionary *)dic {
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary: dic];
    }
    return self;
}

+(instancetype)provinceWithDic:(NSDictionary *)dic {
    return [[self alloc] initWithDic: dic];
}

@end
