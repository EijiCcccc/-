//
//  HMProvince.h
//  城市选择
//
//  Created by hezi on 2021/10/28.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HMProvince : NSObject

@property (nonatomic, copy) NSString *name;
@property (nonatomic, strong) NSArray * cities;

-(instancetype)initWithDic: (NSDictionary *)dic;

+(instancetype)provinceWithDic: (NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
