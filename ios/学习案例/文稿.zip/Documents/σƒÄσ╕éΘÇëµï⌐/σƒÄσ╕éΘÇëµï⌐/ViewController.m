//
//  ViewController.m
//  城市选择
//
//  Created by hezi on 2021/10/28.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ViewController.h"
#import "HMProvince.h"

@interface ViewController () <UIPickerViewDelegate, UIPickerViewDataSource>

@property (nonatomic, strong) NSArray *province;
@property (weak, nonatomic) IBOutlet UILabel *label1;
@property (weak, nonatomic) IBOutlet UILabel *label2;
@property (weak, nonatomic) IBOutlet UIPickerView *pickerView;
@property (nonatomic, strong) HMProvince *selProvince;

@end

@implementation ViewController

-(NSArray *)province {
    if (!_province) {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"citys.plist" ofType: nil];
        NSArray *array = [NSArray arrayWithContentsOfFile: path];
        NSMutableArray *model = [NSMutableArray array];
        for (NSDictionary *dic in array) {
            HMProvince *pro = [HMProvince provinceWithDic: dic];
            [model addObject: pro];
        }
        _province = model;
    }
    return _province;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self pickerView: self.pickerView didSelectRow:0 inComponent:0];
    // Do any additional setup after loading the view.
}

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 2;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    if (component == 0) {
        return self.province.count;
    }
    HMProvince *pro = self.province[[pickerView selectedRowInComponent: 0]];
    self.selProvince = pro;
    return self.selProvince.cities.count;
}

-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
     if (component == 0) {
         return self.selProvince.name;
    }
    return self.selProvince.cities[row];
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    if (component == 0) {
        [pickerView reloadComponent: 1];
        [pickerView selectRow: 0 inComponent: 1 animated: YES];
    }
    NSInteger selCityIdx = [pickerView selectedRowInComponent: 1];
    
    NSString *cityName = self.selProvince.cities[selCityIdx];
    self.label1.text = self.selProvince.name;
    self.label2.text = cityName;
    
}

@end
