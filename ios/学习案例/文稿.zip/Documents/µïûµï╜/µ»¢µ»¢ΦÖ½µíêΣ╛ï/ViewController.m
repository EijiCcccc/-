//
//  ViewController.m
//  毛毛虫案例
//
//  Created by hezi on 2021/11/16.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (nonatomic, strong) UIDynamicAnimator * animator;

@property (nonatomic, strong) UIAttachmentBehavior *attach;

@property (nonatomic, strong) NSMutableArray  *bodys;

@end

@implementation ViewController

- (NSMutableArray *)bodys {
    if (!_bodys) {
        _bodys = [NSMutableArray array];
    }
    return _bodys;
}

- (UIDynamicAnimator *)animator {
    if (!_animator) {
        _animator = [[UIDynamicAnimator alloc] initWithReferenceView: self.view];
    }
    return _animator;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    for (int i = 0; i < 9; i ++) {
        UIView *wormView = [[UIView alloc] init];
        CGFloat w = 30;
        CGFloat h = 30;
        CGFloat x = i * w;
        CGFloat y = 100;
        
        wormView.frame = CGRectMake(x, y, w, h);
        wormView.backgroundColor = [UIColor redColor];
        wormView.layer.cornerRadius = w * 0.5;
        wormView.layer.masksToBounds = YES;
        
        if (i == 8) {
            wormView.frame = CGRectMake(x, y - h * 0.5, 2 * w, 2 * h);
            wormView.backgroundColor = [UIColor blueColor];
            wormView.layer.cornerRadius = w;
            
            UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget: self action: @selector(pan:)];
            
            [wormView addGestureRecognizer: pan];
        }

        [self.bodys addObject: wormView];
        [self.view addSubview: wormView];
    }
    
    for (int i = 0; i < self.bodys.count - 1; i ++) {
        UIAttachmentBehavior *att = [[UIAttachmentBehavior alloc] initWithItem: self.bodys[i] attachedToItem: self.bodys[i + 1]];
        [self.animator addBehavior: att];
    }
    
    UIGravityBehavior *gravity = [[UIGravityBehavior alloc] initWithItems: self.bodys];
    [self.animator addBehavior: gravity];
    
    UICollisionBehavior *collision = [[UICollisionBehavior alloc] initWithItems: self.bodys];
    collision.translatesReferenceBoundsIntoBoundary = YES;
    
    [self.animator addBehavior: collision];
    // Do any additional setup after loading the view.
}

-(void)pan: (UIPanGestureRecognizer *)sender {
    
    // 不能在这置创建Animator
    CGPoint p = [sender locationInView: self.view];
    if (!self.attach) {
        UIAttachmentBehavior *att = [[UIAttachmentBehavior alloc] initWithItem: sender.view attachedToAnchor: p];
        self.attach = att;
    }
    self.attach.anchorPoint = p;
    [self.animator addBehavior: self.attach];
    
    if (sender.state == UIGestureRecognizerStateEnded) {
        [self.animator removeBehavior: self.attach];
    }
}

@end
