//
//  ViewController.m
//  画板
//
//  Created by hezi on 2021/11/15.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ViewController.h"
#import "CYView.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet CYView *drawView;
@property (weak, nonatomic) IBOutlet UISlider *slider;
@property (weak, nonatomic) IBOutlet UIButton *firstBtn;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.drawView.lineWidth = self.slider.value;
    [self lineColorChange: self.firstBtn];
    // Do any additional setup after loading the view.
}
- (IBAction)lineWidthChange:(UISlider *)sender {
    self.drawView.lineWidth = sender.value;
}
- (IBAction)lineColorChange:(UIButton *)sender {
    self.drawView.lineColor = sender.backgroundColor;
}
- (IBAction)removeAllLines:(id)sender {
    [self.drawView remove];
}
- (IBAction)backLines:(id)sender {
    
    [self.drawView back];
}
- (IBAction)xpBtnClick:(id)sender {
    
    [self.drawView eraser];
}

- (IBAction)saveBtnClick:(id)sender {
    UIGraphicsBeginImageContextWithOptions(self.drawView.bounds.size, NO, 0);
    
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    [self.drawView.layer renderInContext: ctx];
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    UIImageWriteToSavedPhotosAlbum( image, NULL, NULL, NULL);
}

@end
