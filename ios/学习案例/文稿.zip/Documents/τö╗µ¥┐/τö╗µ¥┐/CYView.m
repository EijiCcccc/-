//
//  CYView.m
//  画板
//
//  Created by hezi on 2021/11/15.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "CYView.h"
#import "CYBezierPath.h"

@interface CYView ()

@property (nonatomic, strong) NSMutableArray *paths;

@end


@implementation CYView

-(NSMutableArray *)paths {
    if (!_paths) {
        _paths = [[NSMutableArray alloc] init];
    }
    return _paths;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    UITouch *t = touches.anyObject;
    CGPoint p = [t locationInView: t.view];
    
    CYBezierPath *path = [[CYBezierPath alloc] init];
    [path setLineWidth: self.lineWidth];
    [path setLineColor1: self.lineColor];
    [self.lineColor set];
    
    [self.paths addObject: path];
    
    [path moveToPoint: p];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
    UITouch *t = touches.anyObject;
    CGPoint p = [t locationInView: t.view];
    [[self.paths lastObject] addLineToPoint: p];
    
    [self setNeedsDisplay];
}

- (void)back {
    [self.paths removeLastObject];
    [self setNeedsDisplay];
}

- (void)remove {
    [self.paths removeAllObjects];
    [self setNeedsDisplay];
}

- (void)eraser {
    self.lineColor = self.backgroundColor;
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    for (CYBezierPath *path in self.paths) {
        [path setLineCapStyle: kCGLineCapRound];
        [path setLineJoinStyle: kCGLineJoinRound];
        [path.lineColor1 set];
        [path stroke];
    }
}

@end
