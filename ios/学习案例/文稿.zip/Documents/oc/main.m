#import <Foundation/Foundation.h>

int main () {
    NSLog(@"11111");
    return 0;
}


// 预处理  检查语法  编译
