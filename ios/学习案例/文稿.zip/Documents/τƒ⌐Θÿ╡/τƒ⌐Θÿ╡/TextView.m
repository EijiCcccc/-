//
//  TextView.m
//  矩阵
//
//  Created by hezi on 2021/11/11.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "TextView.h"

@implementation TextView

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    NSString *str = @"程序猿程序猿";
    NSShadow *shadow = [[NSShadow alloc] init];
    shadow.shadowBlurRadius = 1; //模糊程度，越小越不模糊
    shadow.shadowOffset = CGSizeMake(50, 50);// 阴影偏移量
    shadow.shadowColor = [UIColor blueColor];
//    [str drawAtPoint: CGPointZero withAttributes: nil];
//    [str drawInRect: CGRectMake(0, 0, 300, 300) withAttributes: nil];
    [str drawAtPoint: CGPointMake(5, 5) withAttributes: @{
        NSFontAttributeName: [UIFont systemFontOfSize: 30],
        NSForegroundColorAttributeName: [UIColor redColor],
//        NSBackgroundColorAttributeName: [UIColor greenColor],
        NSUnderlineStyleAttributeName: @2,
        NSShadowAttributeName: shadow
        
    }];
}

@end
