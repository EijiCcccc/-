//
//  ViewController.m
//  矩阵
//
//  Created by hezi on 2021/11/11.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ViewController.h"
#import "CYImageView.h"

@interface ViewController ()

@property (nonatomic, weak) CYImageView *imageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    CYImageView *imageView = [[CYImageView alloc] initWithImage: [UIImage imageNamed:@"p1"]];
//    CYImageView *imageView = [[CYImageView alloc] init];
//    imageView.frame = CGRectMake(0, 0, 100, 100);
//    imageView.image = [UIImage imageNamed:@"p1"];
//
    self.imageView = imageView;
    [self.view addSubview: imageView];
    // Do any additional setup after loading the view.
}


-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    self.imageView.image = [UIImage imageNamed:@"1"];
}

@end
