//
//  ImageView.m
//  矩阵
//
//  Created by hezi on 2021/11/11.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ImageView.h"

@implementation ImageView

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    //平铺到一个区域
//    [[UIImage imageNamed:@"1"] drawAsPatternInRect: rect];
    //从某个点开始绘制
//    [[UIImage imageNamed:@"1"] drawAtPoint: CGPointMake(20, 20)];
    //绘制倒某一个区域（拉伸）
//    [[UIImage imageNamed:@"1"] drawInRect: CGRectMake(0, 0, 300, 300)];
    
}

@end
