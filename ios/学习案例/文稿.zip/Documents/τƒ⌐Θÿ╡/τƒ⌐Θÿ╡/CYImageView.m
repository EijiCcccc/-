//
//  CYImageView.m
//  矩阵
//
//  Created by hezi on 2021/11/11.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "CYImageView.h"

@implementation CYImageView

-(instancetype)initWithImage:(UIImage *)image {
    if (self = [super initWithFrame:CGRectMake(0, 0, image.size.width, image.size.height)]) {
        self.image = image;
    }
    return self;
}

- (void)setImage:(UIImage *)image {
    _image = image;
    [self setNeedsDisplay];
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    CGContextAddArc(ctx, 150, 150, 100, 0, 2 * M_PI, 1);
    
    //裁剪上下文显示区域
    CGContextClip(ctx);
    
    [self.image drawInRect: rect];
}

@end
