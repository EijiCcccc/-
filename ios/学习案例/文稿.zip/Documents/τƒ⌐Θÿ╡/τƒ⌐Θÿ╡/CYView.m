//
//  CYView.m
//  矩阵
//
//  Created by hezi on 2021/11/11.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "CYView.h"

@implementation CYView

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    CGContextSaveGState(ctx);
    
    //旋转
//    CGContextRotateCTM(ctx, M_PI_4);
    //缩放
//    CGContextScaleCTM(ctx, 0.5, 0.5);
    //平移
//    CGContextTranslateCTM(ctx, 150, 150);
//    CGContextAddArc(ctx, 150, 150, 100, 0, 2 * M_PI, 1);
//    CGContextMoveToPoint(ctx, 0, 0);
//    CGContextAddLineToPoint(ctx, 300, 300);
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathAddArc(path, NULL, 150, 150, 100, 0, 2 * M_PI, 1);
    CGPathMoveToPoint(path, NULL, 0, 0);
    CGPathAddLineToPoint(path, NULL, 300, 300);

    CGContextRotateCTM(ctx, M_PI_4);
//    CGPathRelease(path);
    
    
    //在上下文添加路径之前进行旋转缩放平移
//    CGContextAddPath(ctx, path);
    [[UIColor redColor] set];
    CGContextSaveGState(ctx);
    CGContextSetLineWidth(ctx, 10);
    CGContextStrokePath(ctx);
    
    CGContextRestoreGState(ctx);
    CGContextRestoreGState(ctx);
    
    CGContextMoveToPoint(ctx, 20, 20);
    CGContextAddLineToPoint(ctx, 150, 20);
    
    CGContextStrokePath(ctx);
    
}

@end
