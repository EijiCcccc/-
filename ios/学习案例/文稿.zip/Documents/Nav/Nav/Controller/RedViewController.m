//
//  RedViewController.m
//  Nav
//
//  Created by hezi on 2021/11/9.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "RedViewController.h"
#import "GreenViewController.h"

@interface RedViewController ()
- (IBAction)goGreenVcClck:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *textFiled;

@end

@implementation RedViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"红色控制器";
    
    UIButton *btn = [UIButton buttonWithType: UIButtonTypeContactAdd];
    [btn addTarget: self action: @selector(click) forControlEvents: UIControlEventTouchUpInside];
    self.navigationItem.titleView = btn;
    
    UIBarButtonItem *left = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemAdd target: self action: @selector(click)];
    
    UIBarButtonItem *right = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemAdd target: self action: @selector(click)];
    self.navigationItem.leftBarButtonItem = left;
    
    self.navigationItem.rightBarButtonItem = right;
    
    self.navigationItem.rightBarButtonItems = @[right, left];
    
    //设置返回按钮
    UIBarButtonItem *backIitem = [[UIBarButtonItem alloc] initWithTitle: @"back" style: UIBarButtonItemStylePlain target: self action:@selector(click)];
    self.navigationItem.backBarButtonItem = backIitem;
    // Do any additional setup after loading the view from its nib.
}

-(void)click {
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)goGreenVcClck:(id)sender {
    NSString *text = _textFiled.text;
    
    GreenViewController *greenVc = [[GreenViewController alloc] init];
    greenVc.title = text;
    [self.navigationController pushViewController: greenVc animated: YES];
}
@end
