//
//  GreenViewController.m
//  Nav
//
//  Created by hezi on 2021/11/9.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "GreenViewController.h"
#import "BlueViewController.h"

@interface GreenViewController ()
- (IBAction)goBlueVcClick:(id)sender;
- (IBAction)backToRedVcClick:(id)sender;

@end

@implementation GreenViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIBarButtonItem *backIitem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemBookmarks target: self action: @selector(click)];
     self.navigationItem.leftBarButtonItem = backIitem;
    // Do any additional setup after loading the view from its nib.
}
- (void)click {
    [self.navigationController popViewControllerAnimated: YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)goBlueVcClick:(id)sender {
    BlueViewController *vc = [[BlueViewController alloc] init];
    [self.navigationController pushViewController: vc animated: YES];
}
- (IBAction)backToRedVcClick:(id)sender {
    [self.navigationController popViewControllerAnimated: YES];
}
@end
