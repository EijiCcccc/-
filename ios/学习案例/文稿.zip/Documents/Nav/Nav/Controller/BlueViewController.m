//
//  BlueViewController.m
//  Nav
//
//  Created by hezi on 2021/11/9.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "BlueViewController.h"

@interface BlueViewController ()
- (IBAction)backzdVc:(id)sender;
- (IBAction)goBackClick:(id)sender;
- (IBAction)goRootVcClick:(id)sender;

@end

@implementation BlueViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)goRootVcClick:(id)sender {
    [self.navigationController popToRootViewControllerAnimated: YES];
}

- (IBAction)goBackClick:(id)sender {
    [self.navigationController popViewControllerAnimated: YES];
}

- (IBAction)backzdVc:(id)sender {
    NSArray *arr = self.navigationController.viewControllers;
    [self.navigationController popToViewController: arr[0] animated: YES];
}
@end
