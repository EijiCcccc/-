//
//  GreenViewController.h
//  Nav
//
//  Created by hezi on 2021/11/9.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface GreenViewController : BaseViewController

@end

NS_ASSUME_NONNULL_END
