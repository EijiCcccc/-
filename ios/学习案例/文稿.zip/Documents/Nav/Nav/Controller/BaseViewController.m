//
//  BaseViewController.m
//  Nav
//
//  Created by hezi on 2021/11/9.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"%@ ---》加载完成", self.class);
    // Do any additional setup after loading the view.
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear: animated];
    NSLog(@"%@ ---》即将显示", self.class);
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear: animated];
    NSLog(@"%@ ---》已经显示", self.class);
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear: animated];
    NSLog(@"%@ ---》已经消失", self.class);
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear: animated];
    NSLog(@"%@ ---》即将消失", self.class);
}

-(void)dealloc {
    NSLog(@"%@ ---》dealloc", self.class);
}

@end
