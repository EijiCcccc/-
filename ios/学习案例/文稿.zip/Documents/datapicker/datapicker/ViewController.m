//
//  ViewController.m
//  datapicker
//
//  Created by hezi on 2021/10/28.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <UIPickerViewDelegate, UIPickerViewDataSource>

@property (nonatomic, strong) NSArray *foods;

@property (weak, nonatomic) IBOutlet UILabel *food4;
@property (weak, nonatomic) IBOutlet UILabel *food5;
@property (weak, nonatomic) IBOutlet UILabel *food6;
@property (weak, nonatomic) IBOutlet UIPickerView *pickerView;
- (IBAction)click:(id)sender;

@end

@implementation ViewController

-(NSArray *)foods {
    if (_foods == nil) {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"foods.plist" ofType: nil];
        _foods = [NSArray arrayWithContentsOfFile: path];
    }
    return _foods;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    for (int i = 0; i < self.foods.count; i++) {
        [self pickerView: self.pickerView didSelectRow: 0 inComponent: i];
    }
    // Do any additional setup after loading the view.
}

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return self.foods.count;
}
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return [self.foods[component] count];
}

-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    return self.foods[component][row];
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    NSString *food = self.foods[component][row];
    switch (component) {
        case 0:
            self.food4.text = food;
            break;
            
        case 1:
            self.food5.text = food;
            break;
            
        case 2:
            self.food6.text = food;
            break;
            
        default:
            break;
    }
}

- (IBAction)click:(id)sender {
    for (int i = 0; i < self.foods.count; i++) {
        
        [self pickerView: self.pickerView didSelectRow: 0 inComponent: i];
        
        NSUInteger count = [self.foods[i] count];
        
        u_int32_t ranNum = arc4random_uniform((int)count);
        
        NSInteger selRor = [self.pickerView selectedRowInComponent: i];
        
        while (selRor == ranNum) {
            ranNum = arc4random_uniform((int)count);
        }
        [self.pickerView selectRow: ranNum inComponent: i animated: YES];
        [self pickerView:self.pickerView didSelectRow: ranNum inComponent: i];
    }
}
@end
