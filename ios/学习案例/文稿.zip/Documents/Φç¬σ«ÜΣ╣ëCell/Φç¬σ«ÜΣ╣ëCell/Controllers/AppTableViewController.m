//
//  TableViewController.m
//  自定义Cell
//
//  Created by hezi on 2021/10/26.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "AppTableViewController.h"
#import "CZApp.h"
#import "AppCell.h"

@interface AppTableViewController () <AppCellDelegate>

@property (nonatomic, strong) NSArray* arrayModel;

@end

@implementation AppTableViewController

-(void)appCellDidClickDownloadBtn:(AppCell *)cell {
    
    UILabel *lbMsg = [[UILabel alloc] init];
    lbMsg.text = @"正在下载....";
    lbMsg.backgroundColor = [UIColor blackColor];
    lbMsg.textColor = [UIColor redColor];
    CGFloat msgW = 200;
    CGFloat msgH = 20;
    CGFloat msgX = (self.view.frame.size.width - msgW) * 0.5;
    CGFloat msgY = (self.view.frame.size.height - msgH) * 0.5;
    
    lbMsg.frame = CGRectMake(msgX, msgY, msgW, msgH);

    lbMsg.alpha = 0.0;
//    [self.view addSubview: lbMsg];
    [[[UIApplication sharedApplication] keyWindow] addSubview: lbMsg];
    
    [UIView animateWithDuration: 1.0 animations:^{
        lbMsg.alpha = 0.6;
    } completion:^(BOOL finished) {
        if (finished) {
            [UIView animateWithDuration: 1.0 delay: 0.5 options: UIViewAnimationOptionCurveLinear animations:^{
                lbMsg.alpha = 0.0;
            } completion:^(BOOL finished) {
                [lbMsg removeFromSuperview];
            }];
        }
    }];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.rowHeight = 60;
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

-(NSArray *)arrayModel {
    if (_arrayModel == nil) {
        NSString * path = [[NSBundle mainBundle] pathForResource:@"tablelist.plist" ofType:nil];
        NSArray *array = [NSArray arrayWithContentsOfFile: path];
        NSMutableArray *arrayModel = [NSMutableArray array];
          
          for (NSDictionary *dic in array) {
              CZApp *czapp = [CZApp appWithDic: dic];
              [arrayModel addObject: czapp];
          }
        _arrayModel = arrayModel;
    }
    return _arrayModel;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.arrayModel.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    NSString *ID = @"list";
    
    AppCell *cell = [tableView dequeueReusableCellWithIdentifier:ID forIndexPath:indexPath];
    
    cell.model = self.arrayModel[indexPath.row];
    
    cell.delegate = self;
    
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
