//
//  AppCell.h
//  自定义Cell
//
//  Created by hezi on 2021/10/26.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AppCell;
@protocol AppCellDelegate <NSObject>
-(void)appCellDidClickDownloadBtn: (AppCell *) appCell;
@end


@class CZApp;
@interface AppCell : UITableViewCell <AppCellDelegate>

@property (nonatomic, strong) CZApp *model;

@property (nonatomic, weak) id<AppCellDelegate> delegate;

@end

