//
//  AppCell.m
//  自定义Cell
//
//  Created by hezi on 2021/10/26.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "AppCell.h"
#import "CZApp.h"

@interface AppCell ()

@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UILabel *subTitle;
@property (weak, nonatomic) IBOutlet UIButton *downloadBtn;
- (IBAction)downloadBtnClick:(id)sender;

@end

@implementation AppCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setModel:(CZApp *)model {
    _model = model;
    
    self.imageView.image = [UIImage imageNamed: model.icon];
    self.title.text = model.name;
    self.subTitle.text = [NSString stringWithFormat:@"大小%@ | 下载量：%@", model.size, model.download];
    
    if (self.model.isDownloaded) {
        self.downloadBtn.enabled = NO;
    } else {
        self.downloadBtn.enabled = YES;
    }
    
}

- (IBAction)downloadBtnClick:(id)sender {
    self.downloadBtn.enabled = NO;
    self.model.isDownloaded = YES;
    if ([self.delegate respondsToSelector:@selector(appCellDidClickDownloadBtn:)]) {
        [self.delegate appCellDidClickDownloadBtn: self];
    }
}
@end
