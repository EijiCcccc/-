//
//  CZApp.h
//  自定义Cell
//
//  Created by hezi on 2021/10/26.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CZApp : NSObject

@property (nonatomic, copy) NSString *size;
@property (nonatomic, copy) NSString *download;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *icon;
@property (nonatomic, assign) BOOL isDownloaded;

-(instancetype)initWithDic: (NSDictionary *)dic;
+(instancetype)appWithDic: (NSDictionary *)dic;
@end

NS_ASSUME_NONNULL_END
