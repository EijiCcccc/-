//
//  CZApp.m
//  自定义Cell
//
//  Created by hezi on 2021/10/26.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "CZApp.h"

@implementation CZApp

-(instancetype)initWithDic:(NSDictionary *)dic {
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary: dic];
    }
    return self;
}

+(instancetype)appWithDic:(NSDictionary *)dic {
    return  [[self alloc] initWithDic: dic];
}

@end
