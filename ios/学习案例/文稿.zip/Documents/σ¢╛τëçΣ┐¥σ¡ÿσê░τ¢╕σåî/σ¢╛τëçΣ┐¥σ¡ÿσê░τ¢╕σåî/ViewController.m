//
//  ViewController.m
//  图片保存到相册
//
//  Created by hezi on 2021/11/11.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


//-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//
//    UIImage *image = [UIImage imageNamed: @"p1"];
//
//    UIGraphicsBeginImageContextWithOptions(image.size, NO, 0);
//
//    CGContextRef ctx = UIGraphicsGetCurrentContext();
//    CGContextAddArc(ctx, image.size.width * 0.5, image.size.height * 0.5, image.size.width * 0.5, 0, 2 * M_PI, 1);
//    CGContextClip(ctx);
//
//    [image drawAtPoint: CGPointZero];
//
//    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
//
//    UIGraphicsEndImageContext();
//
//    self.imageView.image = newImage;
//
//    //第三个参数标记作用
//    UIImageWriteToSavedPhotosAlbum(newImage, self, @selector(image:didFinishSavingWithError:contextInfo:), @"aaaaa");
//}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo{
    NSLog(@"保存成功 %@", contextInfo);
}

//-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    UIImage *image = [UIImage imageNamed:@"p1"];
//    CGFloat margin = 10;
//    CGSize ctxSize = CGSizeMake(image.size.width + 2 * margin,
//                                image.size.height + 2 * margin);
//    UIGraphicsBeginImageContextWithOptions(ctxSize, NO, 0);
//
//    CGContextRef ctx = UIGraphicsGetCurrentContext();
//    CGPoint ctxCenter = CGPointMake(ctxSize.width * 0.5, ctxSize.height * 0.5);
//    CGFloat center = ( image.size.width + margin ) * 0.5;
//    CGContextAddArc(ctx, ctxCenter.x, ctxCenter.y, center, 0, 2 * M_PI, 1);
//    CGContextSetLineWidth(ctx, margin);
//    CGContextStrokePath(ctx);
//
//    CGContextAddArc(ctx, ctxCenter.x, ctxCenter.y, image.size.width * 0.5, 0, 2 * M_PI, 1);
//    CGContextClip(ctx);
//    [image drawAtPoint:CGPointMake(margin, margin)];
//
//    image = UIGraphicsGetImageFromCurrentImageContext();
//
//
//    UIGraphicsEndImageContext();
//    self.imageView.image = image;
////    UIImageWriteToSavedPhotosAlbum(image, NULL, NULL, NULL);
//}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    //添加水印
    UIImage *image = [UIImage imageNamed:@"p1"];
    UIGraphicsBeginImageContextWithOptions(image.size, NO, 0);
    
    [image drawAtPoint: CGPointZero];
    
    NSString *str = @"必属精品";
    
    UIImage *logo = [UIImage imageNamed:@"logo_welcome"];
    
    [logo drawAtPoint:CGPointMake(image.size.width * 0.7, image.size.height * 0.6)];
    
    [str drawAtPoint:CGPointMake(20, 20) withAttributes:@{
        NSFontAttributeName: [UIFont systemFontOfSize: 20],
    }];
    
    image = UIGraphicsGetImageFromCurrentImageContext();

    self.imageView.image = image;
    
    UIGraphicsEndImageContext();
    
    
    //截图
    UIGraphicsBeginImageContextWithOptions(self.view.bounds.size, NO, 0);
      
    CGContextRef ctx = UIGraphicsGetCurrentContext();

    [self.view.layer renderInContext: ctx];

    UIImage *image1 = UIGraphicsGetImageFromCurrentImageContext();

    UIGraphicsEndImageContext();

    UIImageWriteToSavedPhotosAlbum(image1, NULL, NULL, NULL);
}

@end
