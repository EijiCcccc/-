//
//  CYView.m
//  触摸事件
//
//  Created by hezi on 2021/11/12.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "CYView.h"

@implementation CYView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    NSLog(@"%s", __func__);
//    NSLog(@"%@", touches);
    UITouch *t = touches.anyObject;
    CGPoint p = [t locationInView: self.superview];
    self.center = p;

}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    UITouch *t = touches.anyObject;
    CGPoint p = [t locationInView: self.superview];
    CGPoint lastP = [t previousLocationInView: self.superview];
    
    CGFloat offsetX = p.x - lastP.x;
    CGFloat offsetY = p.y - lastP.y;
    self.center = CGPointMake(self.center.x + offsetX, self.center.y + offsetY);
//    self.center = p;
}

//意外中断
- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
     NSLog(@"%s", __func__);
}

@end
