//
//  BGView.m
//  触摸事件
//
//  Created by hezi on 2021/11/12.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "BGView.h"
#import "CYView.h"

@interface BGView ()
@property (weak, nonatomic) IBOutlet CYView *colorView;

@property (nonatomic, strong) NSArray *images;

@end

@implementation BGView

-(NSArray *)images {
    if (!_images) {
        _images = @[[UIImage imageNamed:@"like"],
                    [UIImage imageNamed:@"icon_like_small_path"]];
    }
    return _images;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
    [self addSpark: touches];

}

-(void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self addSpark: touches];
}

//-(UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
//
//    if (self.userInteractionEnabled == NO || self.alpha <= 0.01 || self.hidden == YES) {
//        return  nil;
//    }
//
//    if (![self pointInside: point withEvent: event]) {
//        return  nil;
//    }
//
//    for (int i = (int)self.subviews.count - 1; i >= 0; i--) {
//        UIView *lastVw = self.subviews[i];
//        CGPoint subPoint = [self convertPoint:point toView: lastVw];
//        UIView *nextVw = [lastVw hitTest:subPoint withEvent: event];
//        if (nextVw) {
//            return nextVw;
//        }
//    }
//
//    return self;
//}

-(void)addSpark: (NSSet *)touches {
    int i = 0;
    for (UITouch *t in touches) {
        CGPoint p = [t locationInView: t.view];
        
        UIImageView *imageView= [[UIImageView alloc] initWithImage: self.images[i]];
        imageView.center = p;
        [self addSubview:imageView];
        NSLog(@"%lu", touches.count);
        
        [UIView animateWithDuration: 2 animations:^{
            imageView.alpha = 0;
        } completion:^(BOOL finished) {
            
            [imageView removeFromSuperview];
        }];
        i++;
    }
}

@end
