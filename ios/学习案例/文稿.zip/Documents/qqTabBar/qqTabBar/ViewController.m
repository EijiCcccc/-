//
//  ViewController.m
//  qqTabBar
//
//  Created by hezi on 2021/11/10.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
