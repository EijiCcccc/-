//
//  ViewController.m
//  autoresizing1
//
//  Created by hezi on 2021/10/27.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
- (IBAction)click:(id)sender;
@property (nonatomic, weak) UIView* blueView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIView *blueView = [[UIView alloc] init];
    blueView.backgroundColor = [UIColor blueColor];
    blueView.frame = CGRectMake(0, 0, 200, 200);
    [self.view addSubview: blueView];
    
    self.blueView = blueView;
    
    UIView *redView = [[UIView alloc] init];
    redView.backgroundColor = [UIColor redColor];
    
    CGFloat redW = blueView.frame.size.width;
    CGFloat redH = 50;
    CGFloat redX = 0;
    CGFloat redY = blueView.frame.size.height - redH;
    redView.frame = CGRectMake(redX, redY, redW, redH);
    redView.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleWidth; 
    
    /*
    UIViewAutoresizingNone                 = 0,
    UIViewAutoresizingFlexibleLeftMargin   = 1 << 0,
    UIViewAutoresizingFlexibleWidth        = 1 << 1,
    UIViewAutoresizingFlexibleRightMargin  = 1 << 2,
    UIViewAutoresizingFlexibleTopMargin    = 1 << 3,
    UIViewAutoresizingFlexibleHeight       = 1 << 4,
    UIViewAutoresizingFlexibleBottomMargin = 1 << 5
     */
    
    [blueView addSubview: redView];
    // Do any additional setup after loading the view.
}


- (IBAction)click:(id)sender {
    CGRect blueFrame = self.blueView.frame;
    blueFrame.size.width += 20;
    blueFrame.size.height += 20;
    self.blueView.frame = blueFrame;
}
@end
