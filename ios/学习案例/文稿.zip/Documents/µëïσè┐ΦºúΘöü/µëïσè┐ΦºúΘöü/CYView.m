//
//  CYView.m
//  手势解锁
//
//  Created by hezi on 2021/11/12.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "CYView.h"

#define kButtonCount 9

@interface CYView ()

@property (nonatomic, strong) NSMutableArray *btns;

@property (nonatomic, strong) NSMutableArray *lineBtns;

@property (nonatomic, assign) CGPoint point;

@end

@implementation CYView

-(NSMutableArray *)lineBtns {
    if (!_lineBtns) {
        _lineBtns = [NSMutableArray array];
    }
    return  _lineBtns;
}

- (NSMutableArray *)btns {
    if (!_btns) {
        _btns = [NSMutableArray array];
        
        for (int i = 0; i < kButtonCount; i++) {
            UIButton *btn = [[UIButton alloc] init];
            
            btn.userInteractionEnabled = NO;
            
            [btn setBackgroundImage: [UIImage imageNamed:@"p2"] forState:UIControlStateNormal];
            
            
            [btn setBackgroundImage: [UIImage imageNamed:@"p1"] forState: UIControlStateSelected];
            
            [btn setBackgroundImage: [UIImage imageNamed:@"p3"] forState: UIControlStateDisabled];
            
            btn.tag = i;
            
            [self addSubview: btn];
            // 使用self.btns 时会调用get方法，但不会崩溃，此时_btns不为空，不执行for
            [_btns addObject:btn];
        }
    }
    return _btns;
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    UITouch *t = touches.anyObject;
    
    CGPoint p = [t locationInView: t.view];
    
    for (int i = 0; i < self.btns.count ; i++) {
        UIButton *btn = self.btns[i];
        if (CGRectContainsPoint(btn.frame, p)) {
            btn.selected = YES;
            [self.lineBtns addObject: btn];
        }
    }
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    UITouch *t = touches.anyObject;
    
    CGPoint p = [t locationInView: t.view];
    
    self.point = p;
    
    for (int i = 0; i < self.btns.count ; i++) {
        UIButton *btn = self.btns[i];
        if (CGRectContainsPoint(btn.frame, p)) {
            btn.selected = YES;
            
            //lineBtns 是否包含按钮
            if (![self.lineBtns containsObject: btn]) {
                [self.lineBtns addObject: btn];
            }
        }
    }
    
    [self setNeedsDisplay];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
    self.userInteractionEnabled = NO;
    
    self.point = [[self.lineBtns lastObject] center];
    
    [self setNeedsDisplay];
    
    NSString *password = @"";
    for (int i = 0; i < self.lineBtns.count; i++) {
        UIButton *btn = self.lineBtns[i];
        btn.selected = NO;
        btn.enabled = NO;
        password = [password stringByAppendingString: [NSString stringWithFormat: @"%ld", btn.tag]];
    }
    if (self.passwordBlock) {
        if (self.passwordBlock(password)) {
            NSLog(@"YES");
        } else {
            NSLog(@"NO");
        }
    }
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        self.userInteractionEnabled = YES;
        [self clear];
    });
}

-(void)clear {
    for (int i = 0; i < self.btns.count ; i++) {
        UIButton *btn = self.btns[i];
        btn.selected = NO;
        btn.enabled = YES;
    }
    [self.lineBtns removeAllObjects];
    [self setNeedsDisplay];
}

-(void)layoutSubviews {
    [super layoutSubviews];
    CGFloat w = 74;
    CGFloat h = 74;
    int colCount = 3;
    CGFloat margin = (self.frame.size.width - 3 * w ) / 4;
    for (int i = 0; i < self.btns.count; i++) {
        CGFloat x = (i % colCount) * (margin + w) + margin;
        CGFloat y = (i / colCount) * (margin + w) + margin;
        [self.btns[i] setFrame:CGRectMake(x, y, w, h)];
    }
}

-(void)drawRect:(CGRect)rect {
    
    if (!self.lineBtns.count) {
        return;
    }
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    
    for (int i = 0; i < self.lineBtns.count; i++) {
        UIButton *btn = self.lineBtns[i];
        
        if (i == 0) {
            [path moveToPoint: btn.center];
        } else {
            [path addLineToPoint: btn.center];
        }
    }
    [path addLineToPoint: self.point];
    [[UIColor whiteColor] set];
    [path setLineWidth: 10];
    [path setLineJoinStyle: kCGLineJoinRound];
    [path setLineCapStyle: kCGLineCapRound];
    [path stroke];
}

@end
