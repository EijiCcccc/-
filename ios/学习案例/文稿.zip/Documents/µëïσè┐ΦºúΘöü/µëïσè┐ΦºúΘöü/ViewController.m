//
//  ViewController.m
//  手势解锁
//
//  Created by hezi on 2021/11/12.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ViewController.h"
#import "CYView.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet CYView *passwrod;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //设置控制器 view的背景为一张图片（平铺）
    self.view.backgroundColor = [UIColor colorWithPatternImage: [UIImage imageNamed:@"Bg"]];
    self.passwrod.passwordBlock = ^(NSString * pwd) {
        if ([pwd isEqualToString:@"0123"]) {
            NSLog(@"right!");
            return YES;
        } else {
            NSLog(@"wrong");
            return NO;
        }
    };
    // Do any additional setup after loading the view.
}


@end
