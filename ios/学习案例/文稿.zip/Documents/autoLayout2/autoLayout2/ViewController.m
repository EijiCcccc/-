//
//  ViewController.m
//  autoLayout2
//
//  Created by hezi on 2021/10/27.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UIView *blueView = [[UIView alloc] init];
    blueView.backgroundColor = [UIColor blueColor];
    [self.view addSubview: blueView];
    
    UIView *redView = [[UIView alloc] init];
    redView.backgroundColor = [UIColor redColor];
    [self.view addSubview: redView];
    
    blueView.translatesAutoresizingMaskIntoConstraints = NO;
    redView.translatesAutoresizingMaskIntoConstraints = NO;
    
    NSLayoutConstraint *blueHC = [NSLayoutConstraint constraintWithItem: blueView attribute: NSLayoutAttributeHeight relatedBy: NSLayoutRelationEqual toItem: nil attribute: NSLayoutAttributeNotAnAttribute  multiplier: 1.0 constant: 50];
    
    NSLayoutConstraint *blueLeft = [NSLayoutConstraint constraintWithItem: blueView attribute: NSLayoutAttributeLeft relatedBy: NSLayoutRelationEqual toItem: blueView.superview attribute: NSLayoutAttributeLeft  multiplier: 1.0 constant: 30];
    
    NSLayoutConstraint *blueTop = [NSLayoutConstraint constraintWithItem: blueView attribute: NSLayoutAttributeTop relatedBy: NSLayoutRelationEqual toItem: self.view attribute: NSLayoutAttributeTop  multiplier: 1.0 constant: 30];
    
     NSLayoutConstraint *blueRight = [NSLayoutConstraint constraintWithItem: blueView attribute: NSLayoutAttributeRight relatedBy: NSLayoutRelationEqual toItem: blueView.superview attribute: NSLayoutAttributeRight  multiplier: 1.0 constant: -30];
    
    NSLayoutConstraint *redHC = [NSLayoutConstraint constraintWithItem: redView attribute: NSLayoutAttributeHeight relatedBy: NSLayoutRelationEqual toItem:blueView attribute:NSLayoutAttributeHeight multiplier:1.0 constant:0];
    
    
    NSLayoutConstraint *redTop = [NSLayoutConstraint constraintWithItem: redView attribute: NSLayoutAttributeTop relatedBy: NSLayoutRelationEqual toItem:blueView attribute:NSLayoutAttributeBottom multiplier: 1.0 constant: 30];
    
    NSLayoutConstraint *redRight = [NSLayoutConstraint constraintWithItem: redView attribute: NSLayoutAttributeRight relatedBy: NSLayoutRelationEqual toItem:blueView attribute:NSLayoutAttributeRight multiplier: 1.0 constant: 0];
    
    NSLayoutConstraint *redWidth = [NSLayoutConstraint constraintWithItem: redView attribute: NSLayoutAttributeWidth relatedBy: NSLayoutRelationEqual toItem:blueView attribute:NSLayoutAttributeWidth multiplier: 0.5 constant: 0];
    
    [self.view addConstraint: blueHC];
    
    [self.view addConstraint: blueLeft];
    
    [self.view addConstraint: blueTop];
    
    [self.view addConstraint: blueRight];
    
    [self.view addConstraint: redHC];
    
    [self.view addConstraint: redTop];
    
    [self.view addConstraint: redRight];
    
    [self.view addConstraint: redWidth];
}


@end
