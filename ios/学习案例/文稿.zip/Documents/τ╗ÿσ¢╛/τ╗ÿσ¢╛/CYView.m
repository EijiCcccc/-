//
//  CYView.m
//  绘图
//
//  Created by hezi on 2021/11/10.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "CYView.h"

@implementation CYView

/*
1.只能在这个方法中国呢获取到正确的上下文
2.rect 参数含义
 当前view的bounds
3.系统调用
 当这个view第一次显示的时候会调用
 当这个view进行重绘的时候会调用
4.如何重绘
 调用某一个需要重绘view对象的setNeedsDisplay
 调用某一个需要重绘view对象的setNeedsDisplayInRect rect: 需要重绘的区域
5.手动调用drawrect的时候，可能获取不到正确的上下文
 
 
 */
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    //矩形
//    [[UIBezierPath bezierPathWithRect: CGRectMake(100, 100, 100, 100)] stroke];
    //圆角矩形， radius大于长宽的 2 / 3时，会显示成圆
//    [[UIBezierPath bezierPathWithRoundedRect:CGRectMake(100, 100, 100, 100) cornerRadius: 30] stroke];
    //椭圆
//    [[UIBezierPath bezierPathWithOvalInRect:CGRectMake(0, 0, 200, 100)] stroke];
    /*圆
     arcCenter： 圆心
     radius 半径
     startAngle 起始位置 0度 3点钟方向
     endAngle 结束位置  180度 9点钟方向
     clockwise 是否是顺时针
     */
//    [[UIBezierPath bezierPathWithArcCenter:CGPointMake(150, 150) radius: 100 startAngle: - M_PI_2 endAngle: M_PI clockwise: 1] stroke];
    //路径
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(50, 50)];
    [path addLineToPoint:CGPointMake(100, 100)];
    [path addLineToPoint:CGPointMake(150, 50)];
    [path setLineWidth: 10];
    [path setLineJoinStyle: kCGLineJoinRound];
    [path setLineCapStyle: kCGLineCapRound];
    
    
    [[UIColor redColor] set];
    [[UIColor blueColor] setStroke];
    [[UIColor greenColor] setFill];
    [path closePath];
    [path stroke];
    [path fill];
//    [self test1];
}

-(void)test6 {
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextAddEllipseInRect(ctx, CGRectMake(0, 0, 200, 100));
    CGContextStrokePath(ctx);
}

-(void)test5{
    // oc
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(50, 50)];
    [path addLineToPoint:CGPointMake(100, 100)];
    [path stroke];
}

-(void)test4 {
    //c + oc
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathMoveToPoint(path, NULL, 50, 50);
    CGPathAddLineToPoint(path, NULL, 100, 100);
    
    UIBezierPath *path1 = [UIBezierPath bezierPathWithCGPath: path];
    [path1 addLineToPoint:CGPointMake(150, 50)];
    
    CGContextAddPath(ctx, path1.CGPath);
    CGContextStrokePath(ctx);
}

-(void)test3{ //c + oc
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    UIBezierPath *path = [[UIBezierPath alloc] init];
    [path moveToPoint:CGPointMake(50, 50)];
    [path addLineToPoint:CGPointMake(100, 100)];
    
    CGContextAddPath(ctx, path.CGPath);
    
    CGContextStrokePath(ctx);
}

-(void)test2 {
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGMutablePathRef path  = CGPathCreateMutable();
    CGPathMoveToPoint(path, NULL, 50, 50);
    CGPathAddLineToPoint(path, NULL, 100, 100);
    
    CGContextAddPath(ctx, path);
    
    CGContextStrokePath(ctx);
}


-(void)test1 {
    //c
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextMoveToPoint(ctx, 50, 50);
    CGContextAddLineToPoint(ctx, 100, 100);
    CGContextAddLineToPoint(ctx, 150, 50);

    CGContextSetLineWidth(ctx, 10);
    CGContextSetLineJoin(ctx, kCGLineJoinBevel);
    CGContextSetLineCap(ctx, kCGLineCapButt);
//    CGContextMoveToPoint(ctx, 50, 200);
//    CGContextAddLineToPoint(ctx, 200, 200);

    [[UIColor redColor] setStroke];
    [[UIColor greenColor] setFill];
//    CGContextStrokePath(ctx);
    CGContextDrawPath(ctx, kCGPathFillStroke);
}

@end
