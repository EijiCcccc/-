//
//  Cy3View.m
//  绘图
//
//  Created by hezi on 2021/11/11.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "Cy3View.h"

@implementation Cy3View


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter: CGPointMake(150, 150) radius:100 startAngle: 0 endAngle: M_PI * 2 clockwise: 0];
    UIBezierPath *path1 = [UIBezierPath bezierPathWithArcCenter: CGPointMake(150, 150) radius: 50 startAngle: 0 endAngle: M_PI * 2 clockwise: 1];
    CGContextAddPath(ctx, path.CGPath);
    CGContextAddPath(ctx, path1.CGPath);
    
    CGContextDrawPath(ctx, kCGPathFill);
}


@end
