//
//  RectView.m
//  绘图
//
//  Created by hezi on 2021/11/11.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "RectView.h"

@implementation RectView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    NSArray *array = @[@0.8, @0.5, @0.7, @0.3, @0.1, @0.6, @0.9, @0.2];
    for (int i = 0; i < array.count; i++) {
      CGFloat w = 20;
      CGFloat h = [array[i] floatValue] * rect.size.height;
      CGFloat x = i * 2 * w;
      CGFloat y = rect.size.height - h;
      UIBezierPath *path = [UIBezierPath bezierPathWithRect:CGRectMake(x, y, w, h)];
      [[UIColor colorWithRed:(float)arc4random_uniform(256) / 255.0 green: (float)arc4random_uniform(256) / 255.0 blue: (float)arc4random_uniform(256) / 255.0 alpha: 1.0] set];
      [path fill];
    }
}

@end
