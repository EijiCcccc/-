//
//  CView.m
//  绘图
//
//  Created by hezi on 2021/11/11.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "CView.h"

@implementation CView

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    NSArray *array = @[@0.3, @0.1, @0.2, @0.4];
    
    CGFloat start = 0;
    CGFloat end = 0;
    for (NSNumber *num in array) {
        end = 2 * M_PI * [num floatValue] + start;
        
        UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter: CGPointMake(150, 150) radius: 100 startAngle: start endAngle: end clockwise: 1];
        [path addLineToPoint: CGPointMake(150, 150)];
        
        [[UIColor colorWithRed:(float)arc4random_uniform(256) / 255.0 green: (float)arc4random_uniform(256) / 255.0 blue: (float)arc4random_uniform(256) / 255.0 alpha: 1.0] set];
        [path fill];
        
        start = end;
    }
    // Drawing code
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    //重绘
//    [self setNeedsDisplay];
    [self setNeedsDisplayInRect:CGRectMake(0, 0, 150, 150)];
}

@end
