//
//  ViewController.m
//  动画
//
//  Created by hezi on 2021/11/15.
//  Copyright © 2021 hezi. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@property (nonatomic, strong) CALayer *layer;

@property (nonatomic, assign) NSInteger imageName;


@end

@implementation ViewController

- (IBAction)imageChanged:(UISwipeGestureRecognizer * )sender {
    self.imageName ++;
    
    if (self.imageName == 3) {
        self.imageName = 0;
    }
    
    self.imageView.image = [UIImage imageNamed: [NSString stringWithFormat:@"%ld", self.imageName + 1]];
    
    CATransition *anim = [[CATransition alloc] init];
    anim.type = @"cube";
    if (sender.direction == UISwipeGestureRecognizerDirectionLeft) {
        
        anim.subtype = kCATransitionFromRight;
    } else {
        
        anim.subtype = kCATransitionFromLeft;
    }
    [self.imageView.layer addAnimation: anim forKey: nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    UIView *redView = [[UIView alloc] init];
    redView.frame = CGRectMake(100, 100, 20, 20);
    redView.backgroundColor = [UIColor redColor];
    self.layer = redView.layer;
    [self.view addSubview: redView];
    // Do any additional setup after loading the view.
}

//-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    CAAnimationGroup *group = [[CAAnimationGroup alloc] init];
//    
//    
//    CABasicAnimation *anim = [[CABasicAnimation alloc] init];
//    anim.keyPath = @"transform.rotation";
//    anim.byValue = @(2 * M_PI);
//    
//    
//    CAKeyframeAnimation *anim1 = [[CAKeyframeAnimation alloc] init];
//        
//    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(150, 150) radius:100 startAngle:0 endAngle:2* M_PI clockwise: 1];
//    anim1.path = path.CGPath;
//    anim1.keyPath = @"position";
//    
//    
//    group.animations = @[anim, anim1];
//    group.duration = 3;
//    group.repeatCount = INT_MAX;
//    
//    [self.layer addAnimation: group forKey: nil];
//}

- (void) test2 {
    CAKeyframeAnimation *anim = [[CAKeyframeAnimation alloc] init];
    
//    NSValue *v1 = [NSValue valueWithCGPoint: CGPointMake(100, 100)];
//     NSValue *v2 = [NSValue valueWithCGPoint: CGPointMake(150, 100)];
//     NSValue *v3 = [NSValue valueWithCGPoint: CGPointMake(100, 150)];
//     NSValue *v4 = [NSValue valueWithCGPoint: CGPointMake(150, 150)];
//    NSValue *v5 = [NSValue valueWithCGPoint: CGPointMake(100, 100)];
//    anim.values = @[v1, v2, v3 ,v4, v5];
    
    
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(150, 150) radius:100 startAngle:0 endAngle:2* M_PI clockwise: 1];
    anim.path = path.CGPath;
    
    
    anim.keyPath = @"position";
    anim.duration = 2;
    
    anim.repeatCount = INT_MAX;
    
    [self.layer addAnimation: anim forKey: nil];
}

- (void)test1 {
    CABasicAnimation *anim = [[CABasicAnimation alloc] init];
    
    anim.keyPath = @"position.x";
    anim.fromValue = @(10);
    anim.toValue = @300;
    
//    anim.byValue = @10;
    
    anim.fillMode = kCAFillModeForwards;
    anim.removedOnCompletion = NO;
    
    
    [self.layer addAnimation: anim forKey: nil];
}

@end
