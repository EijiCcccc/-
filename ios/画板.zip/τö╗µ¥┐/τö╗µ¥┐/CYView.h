//
//  CYView.h
//  画板
//
//  Created by hezi on 2021/11/15.
//  Copyright © 2021 hezi. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CYView : UIView

@property (nonatomic, assign) CGFloat lineWidth;

@property (nonatomic, strong) UIColor *lineColor;

-(void)remove;

-(void)back;

-(void)eraser;

@end

NS_ASSUME_NONNULL_END
